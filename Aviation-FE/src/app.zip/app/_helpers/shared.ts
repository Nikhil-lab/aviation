import { Output, EventEmitter } from '@angular/core';

export class SharedService {

    ethicaBaseUrl: string="";
    removeTrainingFile:boolean=false;

    getBaseUrl(){
        return this.ethicaBaseUrl;
    }


    setBaseUrl(baseUrl: string) {
        console.log("setting url");
        console.log(baseUrl);
        this.ethicaBaseUrl = baseUrl;
    }

    getTrain(){
        this.removeTrainingFile=true;
        console.log("train file disabled");
    }

    setTrain(){
        this.removeTrainingFile=false;
    }


}