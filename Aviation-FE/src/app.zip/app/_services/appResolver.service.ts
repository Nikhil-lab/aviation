import { Injectable } from '@angular/core';
import { Router, Resolve, RouterStateSnapshot, ActivatedRouteSnapshot } from '@angular/router';
//import { Response } from "@angular/http";
import { HttpClient } from '@angular/common/http';
import { Observable, pipe } from "rxjs";
import { map } from 'rxjs/operators';

@Injectable({
	providedIn: 'root'
})
export class AppResolver implements Resolve<any> {
	constructor(private http: HttpClient) { }

	resolve(route: ActivatedRouteSnapshot, state: RouterStateSnapshot): Observable<any> {

		this.http.get('assets/conf/envconfig.json').subscribe(res=>{
			console.log("checking result in app resolver");
			console.log(res['baseURL']);
		}, error=>{
			console.log(error);
		});
		return this.http.get('assets/conf/envconfig.json')
						.pipe(map(res => res));
	}
}