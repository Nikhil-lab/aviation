import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AppraisalComponent } from './ethica/USER-Flow/appraisal.component';
import { FinalComponent } from './ethica/USER-Flow/final/final.component';
import { TestComponent } from './ethica/test/test.component';
import { AuthGuard } from './auth/auth-guard';
import { InitialScreenComponent } from './ethica/SME-Flow/initial-screen/initial-screen.component';
import { EthicaScoreComponent } from './ethica/SME-Flow/ethica-score/ethica-score.component';
import { EditScreenComponent } from './ethica/SME-Flow/edit-screen/edit-screen.component';
import { AddScreenComponent } from './ethica/SME-Flow/add-screen/add-screen.component';
import { ModelDetailsComponent } from './ethica/SME-Flow/new-model-flow/model-details/model-details.component';
import { EthicaCoreComponent } from './ethica/SME-Flow/new-model-flow/ethica-core/ethica-core.component';
import { EthicaComponent } from './ethica/ethica.component';
import { DrilldownComponent } from './ethica/SME-Flow/drilldown/drilldown.component';
import { GridTestComponent } from './ethica/SME-Flow/drilldown/grid-test/grid-test.component';
import { SecondLevelDrilldownComponent } from './ethica/SME-Flow/drilldown/second-level-drilldown/second-level-drilldown.component';


// const routes: Routes = [
//   { path: '', pathMatch: 'full', redirectTo: 'auth/login'},
//   {path:'ethica',component:EthicaComponent},
//   {path:'appraisal', component:AppraisalComponent,canActivate:[AuthGuard]},
//   {path:'submit', component:FinalComponent,canActivate:[AuthGuard]},
//   {path:"test",component:TestComponent},
//   {path:"score",component:EthicaScoreComponent,canActivate:[AuthGuard]},
//   {path:"initial", component:InitialScreenComponent,canActivate:[AuthGuard]},
//   // {path:"initial/:pie", component:InitialScreenComponent,canActivate:[AuthGuard]},
//   {path:"addScreen",component:AddScreenComponent,canActivate:[AuthGuard]},
//   {path:"editScreen",component:EditScreenComponent,canActivate:[AuthGuard]},
//   {path:"sme/modelDetails", component:ModelDetailsComponent,canActivate:[AuthGuard]},
//   {path:"sme/ethicaCore", component:EthicaCoreComponent,canActivate:[AuthGuard]},
//   {path:"drilldown",component:DrilldownComponent,canActivate:[AuthGuard]},
//   {path:"secondleveldrilldown",component:SecondLevelDrilldownComponent,canActivate:[AuthGuard]},
//   {path:"drilltest",component:GridTestComponent,canActivate:[AuthGuard]},
//   // {path:"auth",loadChildren:"../app/ethica/auth/auth.module#AuthModule"},
//   {path:"auth",loadChildren:()=>import('./auth/auth.module').then(m=>m.AuthModule)},
//   { path: 'customers', loadChildren: () => import('./customers/customers.module').then(m => m.CustomersModule) }
// ];

const routes: Routes = [
  { path: '', pathMatch: 'full', redirectTo: 'auth/login'},
  {path:'ethica',component:EthicaComponent},
  {path:'appraisal', component:AppraisalComponent},
  {path:'submit', component:FinalComponent},
  {path:"test",component:TestComponent},
  {path:"score",component:EthicaScoreComponent},
  {path:"initial", component:InitialScreenComponent},
  // {path:"initial/:pie", component:InitialScreenComponent,canActivate:[AuthGuard]},
  {path:"addScreen",component:AddScreenComponent},
  {path:"editScreen",component:EditScreenComponent},
  {path:"sme/modelDetails", component:ModelDetailsComponent},
  {path:"sme/ethicaCore", component:EthicaCoreComponent},
  {path:"drilldown",component:DrilldownComponent},
  {path:"secondleveldrilldown",component:SecondLevelDrilldownComponent},
  {path:"drilltest",component:GridTestComponent},
  // {path:"auth",loadChildren:"../app/ethica/auth/auth.module#AuthModule"},
  {path:"auth",loadChildren:()=>import('./auth/auth.module').then(m=>m.AuthModule)},
  { path: 'customers', loadChildren: () => import('./customers/customers.module').then(m => m.CustomersModule) }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule],
  providers: [AuthGuard]
})
export class AppRoutingModule { }
