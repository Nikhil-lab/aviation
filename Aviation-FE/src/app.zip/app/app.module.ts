import { BrowserModule } from '@angular/platform-browser';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { NgModule, APP_INITIALIZER } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { HeaderComponent } from './ethica/header/header.component';
import { AppraisalComponent } from './ethica/USER-Flow/appraisal.component';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { EditorModule } from '@tinymce/tinymce-angular';
import { FinalComponent } from './ethica/USER-Flow/final/final.component';
import { ReviewCommentsComponent } from './ethica/USER-Flow/review-comments/review-comments.component';
import { FeedbackCompletedComponent } from './ethica/USER-Flow/feedback-completed/feedback-completed.component';
import { FeedbackComponent } from './ethica/USER-Flow/feedback/feedback.component';
import { FontAwesomeModule } from '@fortawesome/angular-fontawesome';
import { ApiService } from './ethica/api/api.service';
import { HttpClientModule, HttpClient, HTTP_INTERCEPTORS } from '@angular/common/http';
import { SnackBarComponent } from './ethica/snack-bar/snack-bar.component';
import { TestComponent } from './ethica/test/test.component';
import { AuthInterceptor } from './auth/auth-interceptor';
import { ChartsModule } from 'ng2-charts';
import { PieChartComponent } from './ethica/graphs/pie-chart/pie-chart.component';
import { InitialScreenComponent } from './ethica/SME-Flow/initial-screen/initial-screen.component';
import { EthicaScoreComponent } from './ethica/SME-Flow/ethica-score/ethica-score.component';
import { EthicaInputComponent } from './ethica/SME-Flow/ethica-input/ethica-input.component';
import { SimpleDialogComponent } from './ethica/SME-Flow/simple-dialog/simple-dialog.component';
import { BarChartComponent } from './ethica/graphs/bar-chart/bar-chart.component';
import { AddScreenComponent } from './ethica/SME-Flow/add-screen/add-screen.component';
import { EditScreenComponent } from './ethica/SME-Flow/edit-screen/edit-screen.component';
import { AngularMaterialModule } from './angular-material.module';
import { AuthModule } from './auth/auth.module';
import { ConfigService } from './config.service';
import { AppResolver } from './_services/appResolver.service';
import { SharedService } from './_helpers/shared';
import { NewModelGuidelinesComponent } from './ethica/SME-Flow/new-model-guidelines/new-model-guidelines.component';
import { ModelDetailsComponent } from './ethica/SME-Flow/new-model-flow/model-details/model-details.component';
import { EthicaCoreComponent } from './ethica/SME-Flow/new-model-flow/ethica-core/ethica-core.component';
import { ExplanabilityComponent } from './ethica/SME-Flow/new-model-flow/ethica-core/explanability/explanability.component';
import { SurveyFormComponent } from './ethica/SME-Flow/new-model-flow/ethica-core/explanability/survey-form/survey-form.component';
import { NgxDropzoneModule } from 'ngx-dropzone';
import { EthicaComponent } from './ethica/ethica.component';
import { LineChartComponent } from './ethica/graphs/line-chart/line-chart.component';
import { UserListComponent } from './ethica/ADMIN-Flow/user-list/user-list.component';
import { DashboardComponent } from './ethica/ADMIN-Flow/dashboard/dashboard.component';
import { AddFormComponent } from './ethica/ADMIN-Flow/add-form/add-form.component';
import { DrilldownComponent } from './ethica/SME-Flow/drilldown/drilldown.component';
import { PieComponent } from './ethica/SME-Flow/drilldown/pie/pie.component';
import { HelloComponent } from './hello.component';
import { DonutComponent } from './ethica/SME-Flow/drilldown/donut/donut.component';
import { Globals } from './ethica/SME-Flow/drilldown/globals.service';
import { ScatterComponent } from './ethica/SME-Flow/drilldown/scatter/scatter.component';
import { LineComponent } from './ethica/SME-Flow/drilldown/line/line.component';
import { LollipopComponent } from './ethica/SME-Flow/drilldown/lollipop/lollipop.component';
import { BarComponent } from './ethica/SME-Flow/drilldown/bar/bar.component';
import { AreaComponent } from './ethica/SME-Flow/drilldown/area/area.component';
import { RadarComponent } from './ethica/SME-Flow/drilldown/radar/radar.component';
import { PolorComponent } from './ethica/SME-Flow/drilldown/polor/polor.component';
import { HorizontalBarComponent } from './ethica/SME-Flow/drilldown/horizontal-bar/horizontal-bar.component';
import { NgxCsvParserModule } from 'ngx-csv-parser';
import { GridTestComponent } from './ethica/SME-Flow/drilldown/grid-test/grid-test.component';
import { SecondLevelDrilldownComponent } from './ethica/SME-Flow/drilldown/second-level-drilldown/second-level-drilldown.component';


const  appConfig =(config:ConfigService)=>{
  return()=>{
    return config.loadConfig();
  }
}


@NgModule({
  declarations: [
    AppComponent,
     HeaderComponent,
    AppraisalComponent,
    FinalComponent,
    ReviewCommentsComponent,
    FeedbackCompletedComponent,
    FeedbackComponent,
    SnackBarComponent,
    TestComponent,
    PieChartComponent,
     EthicaScoreComponent,
    InitialScreenComponent,
    EthicaInputComponent,
    SimpleDialogComponent,
    BarChartComponent,
    AddScreenComponent,
    EditScreenComponent,
    NewModelGuidelinesComponent,
    ModelDetailsComponent,
    EthicaCoreComponent,
    ExplanabilityComponent,
    SurveyFormComponent,
    EthicaComponent,
    LineChartComponent,
    UserListComponent,
    DashboardComponent,
    AddFormComponent,
    DrilldownComponent,
    PieComponent,
    DonutComponent,
    ScatterComponent,
    LineComponent,
    LollipopComponent,
    BarComponent,
    AreaComponent,
    RadarComponent,
    PolorComponent,
    HorizontalBarComponent,
    GridTestComponent,
    SecondLevelDrilldownComponent
    
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    BrowserAnimationsModule,
    HttpClientModule,
    EditorModule,
    FormsModule,
    FontAwesomeModule,
    ChartsModule,
    AngularMaterialModule,
    ReactiveFormsModule,
    NgxDropzoneModule,
    NgxCsvParserModule
    
    
  ],
  providers: [ApiService,ConfigService,AppResolver,SharedService,Globals,
            { provide:APP_INITIALIZER, useFactory:appConfig, multi: true,deps:[ConfigService]},
            { provide: HTTP_INTERCEPTORS, useClass:AuthInterceptor,multi: true}
            ],
  bootstrap: [AppComponent],
  entryComponents:[PieComponent,HelloComponent,DonutComponent]
})
export class AppModule { }
