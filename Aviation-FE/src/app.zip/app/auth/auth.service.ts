import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Router } from '@angular/router';
import { AuthData } from './auth.data.model';


import { Subject, BehaviorSubject } from 'rxjs';

import {environment} from "../../environments/environment"
import { SharedService } from 'src/app/_helpers/shared';
import { ConfigService } from 'src/app/config.service';
import { LoginComponent } from './login/login.component';

//  const BACKEND_URl=environment['apiUrl']+ "/user/";


@Injectable({
    providedIn: 'root'
})
export class AuthService {
    private token: string;
    private authStatusListner = new BehaviorSubject<boolean>(false);
    private tokenTimer: any;
    private userId: string;
    base:string;



    constructor(private config:ConfigService,private http: HttpClient, private router: Router, private _shared: SharedService) { 
    }

    getToken() {
        console.log("token from service auth")
        console.log(this.token);
        return this.token;
    }
    getAuthStatusListner() {
        return this.authStatusListner.asObservable();
    }

    changeStatus() {
        this.authStatusListner.next(true);

    }

    getUserId() {
        return this.userId;
    }



    createUser(email: string, password: string) {
        const authData: AuthData = {
            email: email,
            password: password

        };

        let base= localStorage.getItem("baseURL");

        return this.http.post(base + "signup", authData).subscribe((response) => {
            console.log(response);
            //this.router.navigate(["/"]);
        }, error => {
            console.log(error);
            //   this.authStatusListner.next(false);
        });

    }



    login(email: string, password: string) {
        const authData: AuthData = {
            email: email,
            password: password

        };
        
        let base= localStorage.getItem("baseURL");

        let checking= this.config.getConfig()
        console.log("checking hereeeee");
        console.log(checking['baseURL']);

        this.http.post<{ token: string; expiresIn: number;userId: string,email: string,role:string}>(base+ "/user/login", authData)
            .subscribe(response => {
                console.log("token received from backend");
                console.log(response);
                const token = response.token;
                this.token = token;
                let role=response.role;

                if (token) {
                    let expirationDuration = response.expiresIn
                    console.log(expirationDuration);

                    this.setAuthTimer(expirationDuration);
                    this.userId=response.userId;
                    
                    this.authStatusListner.next(true);
                    const now = new Date();
                    const expirationDate = new Date(now.getTime() + expirationDuration * 1000);
                    console.log(expirationDate);
                    this.saveAuthData(token, expirationDate,this.userId);


                    if(role == "user"){
                        this.router.navigate(["/appraisal"]);
                    }
                    else {
                        
                            this.router.navigate(["/ethica"]);
                        
                        
                    }

                    //if(role == "admin")
                    
                    // else{
                    //     this.router.navigate(["/initial"]);
                    // }
                    

                }



            }, error => {
                this.router.navigate(["/auth/login"]);
                console.log(error);
                
                //   this.authStatusListner.next(false);
            });

    }


    autoAuthUser(){
        const authInformation = this.getAuthData();
        if(!authInformation){
            return;
        }
        const now=new Date();

        const expiresIn= authInformation.expirationDate.getTime()-now.getTime();
        if(expiresIn >0){
            this.token=authInformation.token;
            this.userId=authInformation.userId;
            this.authStatusListner.next(true);
            this.setAuthTimer(expiresIn/1000);
            console.log("expiration duration"+expiresIn);


        }
    }


    logout() {
        this.token = null;
        this.authStatusListner.next(false);

        clearTimeout(this.tokenTimer);
        this.clearAuthData();
        this.userId = null;
        this.router.navigate(["/auth/login"]);

    }


    private setAuthTimer(duration: number){
        this.tokenTimer = setTimeout(() => {
            this.logout();
        }, duration * 1000);
        
    }

    private saveAuthData(token: string, expirationDate: Date,userId:string) {
        localStorage.setItem("token", token);
        localStorage.setItem("expiration", expirationDate.toISOString());
        localStorage.setItem("userId", userId);
    }

    private clearAuthData() {
        console.log("clearAuthData");
        localStorage.removeItem("token");
        localStorage.removeItem("expiration");
        localStorage.removeItem("userId");
        localStorage.removeItem("baseURL");
    }

    private getAuthData(){
        const token= localStorage.getItem("token");
        const expiration= localStorage.getItem("expiration");
        const userId= localStorage.getItem("userId");

        if(!token || !expiration){
            return;
        }
        return {
            token:token,
            expirationDate:new Date(expiration),
            userId:userId
        }
    }

}
    //       response=>{
    //         console.log(response);
    //         const token = response.token;
    //         this.token=token;

    //         if(token){
    //           const expiresInDuration= response.expiresIn;
    //           console.log(expiresInDuration);
    //          this.setAuthTimer(expiresInDuration);
    //           this.isAuthenticated=true,
    //           this.userId=response.userId,
    //           this.authStatusListner.next(true);
    //           const now=new Date();
    //           const expirationDate =new Date(now.getTime()+expiresInDuration*1000);
    //           console.log(expirationDate)
    //           this.saveAuthData(token,expirationDate,this.userId);
    //           this.router.navigate(['/']);
    //         }

    //       }
    //     ,error=>{
    //       this.authStatusListner.next(false);
    //     });

    //   }


    //   autoAuthUser(){
    //     const autoInformation=this.getAuthData();
    //     if(!autoInformation){
    //       return;
    //     }

    //     const now=new Date();
    //     const expiresIn=autoInformation.expirationDate.getTime()-now.getTime();

    //     if(expiresIn>0){
    //       this.token=autoInformation.token;
    //       this.isAuthenticated=true;
    //       this.userId = autoInformation.userId;
    //       this.setAuthTimer(expiresIn/1000);
    //       this.authStatusListner.next(true);
    //     }


    //   }




    //   logout(){

    //     this.token=null;
    //     this.isAuthenticated=false;
    //     this.authStatusListner.next(false);
    //     clearTimeout(this.tokenTimer);
    //     this.clearAuthData();
    //     this.userId=null;
    //     this.router.navigate(['/']);

    //   }

    //   private saveAuthData(token:string,expirationDate:Date,userId:string) {

    //     localStorage.setItem("token",token);
    //     localStorage.setItem("expiration",expirationDate.toISOString());
    //     localStorage.setItem("userId",userId);

    //   }

    //   private clearAuthData(){
    //     localStorage.removeItem("token");
    //     localStorage.removeItem("expiration");
    //     localStorage.removeItem("userId");
    //   }

    //   private getAuthData(){
    //     const token = localStorage.getItem("token");
    //     const expirationDate = localStorage.getItem("expiration");
    //     const userId=localStorage.getItem("userId");

    //     if(!token || !expirationDate){
    //       return; 
    //     }

    //     return{
    //       token:token,
    //       expirationDate:new Date(expirationDate),
    //       userId:userId

    //     }
    //   }

    //   private setAuthTimer(duration: number){
    //     console.log("expiration duration:"+duration)
    //     this.tokenTimer=setTimeout(()=>{
    //       this.logout();
    //     },duration*1000)
    //   }




