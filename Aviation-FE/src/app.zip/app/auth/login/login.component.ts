import { Component, OnInit, OnDestroy } from "@angular/core";
import { NgForm } from "@angular/forms";
import { Subscription } from "rxjs";
import { AuthService } from '../auth.service';
import { ActivatedRoute } from '@angular/router';
import { SharedService } from 'src/app/_helpers/shared';

@Component({
  templateUrl: "./login.component.html",
  styleUrls: ["./login.component.css"]
})
export class LoginComponent implements OnInit {
  isLoading = false;
  private authStatusSubs: Subscription;

  constructor(private authService: AuthService,private route: ActivatedRoute, private _shared: SharedService){
    this.route.data.subscribe((res) => {
      console.log(res.appConf);
      this._shared.setBaseUrl(res.appConf.baseURL);
      localStorage.setItem("baseURL", res.appConf.baseURL);
  });

  }
 

  ngOnInit() {
  
  }


   onLogin(form: NgForm) {
    console.log(form.value);
    if(form.invalid){
      return;
    }
     this.isLoading = true;
    this.authService.login(form.value.email, form.value.password);
   }
}
