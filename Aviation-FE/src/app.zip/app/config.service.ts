import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class ConfigService {
  private appConfig;

  constructor(private _http: HttpClient) { }

  loadConfig(){
    return this._http.get('../assets/conf/envconfig.json')
    .toPromise()
    .then(res=>{
      this.appConfig= res;
      console.log("env config!!!!!!!!!!!!!!!!");
      console.log(res);
    })
  }

  getConfig(){
    return this.appConfig;
  }

}
