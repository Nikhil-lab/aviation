import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { CustomersRoutingModule } from './customers-routing.module';
import { CustomersComponent } from './customers.component';
import { EthicaScoreComponent } from '../ethica/SME-Flow/ethica-score/ethica-score.component';
import { HeaderComponent } from './header/header.component';


@NgModule({
  declarations: [CustomersComponent, HeaderComponent],
  imports: [
    CommonModule,
    CustomersRoutingModule
  ]
})
export class CustomersModule { }
