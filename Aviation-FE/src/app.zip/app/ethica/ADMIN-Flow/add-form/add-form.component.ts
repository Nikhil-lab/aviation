import { Component, OnInit, Inject } from '@angular/core';
import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material/dialog';
import { MyErrorStateMatcher } from '../../SME-Flow/new-model-flow/model-details/model-details.component';
import { Validators, FormControl } from '@angular/forms';

@Component({
  selector: 'app-add-form',
  templateUrl: './add-form.component.html',
  styleUrls: ['./add-form.component.css']
})
export class AddFormComponent implements OnInit {
  type:string;
  crud:string;
  
  nameFormControl = new FormControl('', [
    Validators.required
  ]);

  passwordFormControl= new FormControl('', [
    Validators.required
  ])
  descriptionFormControl = new FormControl('', [
    Validators.required
  ]);
  group_id = new FormControl();
  selectedRole:string;
  groupList: string[] = ["Wally", "Bills"];
  roles:string[]=['user', 'data_curator','cro'];

  explainabilityPermission;
  transperancyPermission;
  humanFirstPermission;
  interpretabilityPermissions;
  commonSensePermission;
  auditabilityPermission;

  permissions=["Restricted","Read", "Read/Write"];



  nameMatcher = new MyErrorStateMatcher();
  passwordMatcher= new MyErrorStateMatcher();
  descriptionMatcher = new MyErrorStateMatcher();

  constructor( public dialogRef: MatDialogRef<AddFormComponent>,@Inject(MAT_DIALOG_DATA) public data) { }

  ngOnInit(): void {
    console.log(this.data);
    this.type=this.data.type;
    this.crud=this.data.crud;
    if(this.data.name){
      this.nameFormControl.setValue(this.data.name);
    }
    
  }

  submitForm(){
    let userInput;
    console.log(this.nameFormControl.value);
    console.log(this.passwordFormControl.value);
    console.log(this.group_id.value);
    console.log(this.selectedRole);
    console.log(this.explainabilityPermission)

    if(this.type  == "User"){
      userInput={
        user_name:this.nameFormControl.value,
        password:this.passwordFormControl.value,
        group_id:this.group_id.value,
        role:this.selectedRole,
        explainabilityPermission:this.explainabilityPermission,
        transperancyPermission:this.transperancyPermission,
        humanFirstPermission:this.humanFirstPermission,
        interpretabilityPermissions:this.interpretabilityPermissions,
        commonSensePermission:this.commonSensePermission,
        auditabilityPermission:this.auditabilityPermission
        
      }
      this.dialogRef.close(userInput);
    }
    else if(this.type  == "Project"){
      userInput={
        project_name:this.nameFormControl.value,
        group_id:this.group_id.value,
      }
      this.dialogRef.close(userInput);
    }
    else if(this.type  == "Application"){
      userInput={
        application_name:this.nameFormControl.value,
        group_id:this.group_id.value,
      }
      this.dialogRef.close(userInput);
    }else{
      userInput={
        model_name:this.nameFormControl.value,
        group_id:this.group_id.value,
      }
      this.dialogRef.close(userInput);
    }
     

  }

}
