import { Component, OnInit, Input } from '@angular/core';

@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.css']
})
export class DashboardComponent implements OnInit {

  // cards=[
  //   {"Users1":"1,24,293"},
  //   {"Users12":"18,000"},
  //   {"Users13":"2,34,675"},
  //   {"Users13":"4,78,989"},
  //   {"Users14":"11,34,234"}
  // ]

  @Input() cards:any[];
   cardTitles: string[]=[];
  cardTitleValues:string[]=[];
  pieLables:string[]=[];
    pieValues:number[]=[];

  constructor() { }

  ngOnInit(): void {
    console.log(this.cards);
   
    this.cards.forEach(card=>{

        for (let key in card){
          if(key == "model_framework_percentage"){
            let pie=card["model_framework_percentage"]
            for(let label in pie){
              this.pieLables.push(label);
              this.pieValues.push(pie[label]);
            }
          }
          this.cardTitles.push(key);
          this.cardTitleValues.push(card[key]);
        }
    })


  }

}
