import {Component, OnInit, ViewChild, Input, AfterViewInit} from '@angular/core';
import {MatPaginator} from '@angular/material/paginator';
import {MatSort} from '@angular/material/sort';
import {MatTableDataSource} from '@angular/material/table';
import { MatDialog } from '@angular/material/dialog';
import { AddFormComponent } from '../add-form/add-form.component';
import { Router } from '@angular/router';
import { ApiService } from '../../api/api.service';
import { AuthService } from 'src/app/auth/auth.service';

export interface UserData {
  id: string;
  name: string;
  progress: string;
  color: string;
}

/** Constants used to fill up our data base. */
const COLORS: string[] = [
  'maroon', 'red', 'orange', 'yellow', 'olive', 'green', 'purple', 'fuchsia', 'lime', 'teal',
  'aqua', 'blue', 'navy', 'black', 'gray'
];
const NAMES: string[] = [
  'Maia', 'Asher', 'Olivia', 'Atticus', 'Amelia', 'Jack', 'Charlotte', 'Theodore', 'Isla', 'Oliver',
  'Isabella', 'Jasper', 'Cora', 'Levi', 'Violet', 'Arthur', 'Mia', 'Thomas', 'Elizabeth'
];

/**
 * @title Data table with sorting, pagination, and filtering.
 */
@Component({
  selector: 'app-user-list',
  templateUrl: './user-list.component.html',
  styleUrls: ['./user-list.component.css']
})
export class UserListComponent implements OnInit,AfterViewInit {

  userId: string;
  dashboard:boolean=false;
  cards:any[];
  applicationData:any[];
  modelData:any[];
  dataSource: MatTableDataSource<UserData>;
  currentProjectId;
  currentApplicationId;
  currentModelId;
  oldWeightages;
  ETHICA:any[]=[];
  subparameters={"E":[0,0,0,0,0],"T":[0,0,0,0,0],"H":[0,0,0,0,0],"I":[0,0,0,0,0],"C":[0,0,0,0,0],"A":[0,0,0,0,0]};
  subparameterslist={};
  cardTitles: string[]=[]
  cardTitleValues:string[]=[]

  spanningColumns = ['id'];
  spans = [];

  DATA;


  @Input() displayedColumns: string[];
  columnsToDisplay: string[];
  @Input() type:string;
  @Input() data:any[];
  @ViewChild(MatPaginator, {static: true}) paginator: MatPaginator;
  @ViewChild(MatSort, {static: true}) sort: MatSort;
  
  projectData;
  keys=this.displayedColumns;

  constructor(private _dialog: MatDialog,private _router: Router, private _service:ApiService, private _authService:AuthService) {
    // Create 100 users
    const users = Array.from({length: 100}, (_, k) => this.createNewUser(k + 1));

    // Assign the data to the data source for the table to render
    
  }
  ngAfterViewInit(): void {
  }

  ngOnInit() {
    
    this.columnsToDisplay=  this.displayedColumns.concat(['myExtraColumn']);
    console.log(this.columnsToDisplay);
    this.userId=this._authService.getUserId();
    // this.userId= localStorage.getItem("userId");
    this.dataSource = new MatTableDataSource(this.data);
    this.projectData=this.data;
    console.log("dataSource")
    console.log()
    console.log(this.dataSource)

    this.dataSource.paginator = this.paginator;
    this.dataSource.sort = this.sort;
    
  }

  applyFilter(event: Event) {
    const filterValue = (event.target as HTMLInputElement).value;
    this.dataSource.filter = filterValue.trim().toLowerCase();

    if (this.dataSource.paginator) {
      this.dataSource.paginator.firstPage();
    }
  }

  createNewUser(id: number): UserData {
    const name = NAMES[Math.round(Math.random() * (NAMES.length - 1))] + ' ' +
        NAMES[Math.round(Math.random() * (NAMES.length - 1))].charAt(0) + '.';
  
    return {
      id: id.toString(),
      name: name,
      progress: Math.round(Math.random() * 100).toString(),
      color: COLORS[Math.round(Math.random() * (COLORS.length - 1))]
    };
  
  }

 



  editRow(row){
    let userInput={}
    console.log(row)

    
    if(this.type == "Model"){

      let dataToBackend={
        type:"Model",
        user_id:this.userId,
        project_id:this.currentProjectId,
        application_id:this.currentApplicationId,
        model_id:row.model_id
      }
      console.log(dataToBackend);
  
      this._service.postData("/fetch_ethica_score",dataToBackend).subscribe(oldWeightages=>{
         this.oldWeightages=oldWeightages;
      
      this.extractWeightage(this.oldWeightages);

     
      
      this._router.navigate(['/initial',{pie:true}],{ state: { graphData:this.ETHICA,overallParameters:this.subparameters,overallParametersList:this.subparameterslist} 
    })
  }); 

    }else{
      let dialogdata;
      
      if(this.type == "Application"){
         dialogdata={
          crud:"Update",
          type: this.type,
          id:row.application_id,
          name:row.application_name,
          created_by:row.created_by,
          group_id:row.group_id
        }
      }else if(this.type == "Project"){
        dialogdata={
         crud:"Update",
         type: this.type,
         id:row.project_id,
         name:row.project_name,
         created_by:row.created_by,
         group_id:row.group_id
       }
     } else {
      dialogdata={
       crud:"Update",
       type: this.type,
       id:row.user_id,
       name:row.user_name,
       created_by:row.created_by,
       group_id:row.group_id
     }
   }

    if(this.type != "User"){
      

      const dialogRef=this._dialog.open(AddFormComponent,{panelClass: 'myapp-no-padding-dialog',
        data: dialogdata,
        height: '320px',
        width: '400px',
      });

      dialogRef.afterClosed().subscribe(result => {
        console.log('The dialog was closed');
        console.log(result)
        userInput=result;

        userInput["type"]=this.type;
      userInput["user_id"]=this.userId;

      if(this.type == "Application"){
        userInput["application_id"]=row.application_id;
        userInput["project_id"]=this.currentProjectId
      }else{
        userInput["project_id"]=row.project_id;
      }
      console.log("checking user input to backend");
      console.log(userInput);
       this._service.postData("/edit",userInput).subscribe(result => {
         console.log(result);
       })

      });
       
      
    }
    else{
      const dialogRef=this._dialog.open(AddFormComponent,{panelClass: 'myapp-no-padding-dialog',
        data: dialogdata,
        height: '550px',
        width: '500px',
      });

      dialogRef.afterClosed().subscribe(result => {
        console.log('The dialog was closed');
        console.log(result)
        userInput=result
        userInput["user_id"]=this.userId;
        this._service.postData("/edit",userInput).subscribe(result => {
          console.log(result);
        })
      });

    }
      
    }

 

    
  }

  deleteRow(row){
    console.log(event);
    console.log(row)
    let  deleteData

    if(this.type == "User"){
        deleteData={
        type: this.type,
        user_id:row.user_id
      }
    }
    else if( this.type == "Project"){
        deleteData={
          type: this.type,
          user_id:this.userId,
          project_id:row.project_id,

      }
    }
    else if( this.type == "Application"){
        deleteData={
        type: this.type,
        user_id:this.userId,
        project_id:this.currentProjectId,
        application_id:row.application_id
      }
    }else{
      deleteData={
        type: this.type,
        user_id:this.userId,
        project_id:this.currentProjectId,
        application_id:this.currentApplicationId,
        model_id:row.model_id
      }
    }
    
    console.log(deleteData);
    this._service.postData("/delete",deleteData).subscribe(data=>{
      console.log(data);
    });



  }




      viewDashboard(type){
        console.log(type);

        // if(type == "User"){
        //   let usercards=[
        //     {"Users1":"1,24,293"},
        //     {"Users12":"18,000"},
        //     {"Users13":"2,34,675"},
        //     {"Users13":"4,78,989"},
        //     {"Users14":"11,34,234"}
        //   ]
        //   this.cards=usercards;
          
        // }
        // else if (type == "Project"){
        //   let projectcards=[
        //     {"project1":"1,24,293"},
        //     {"project12":"18,000"},
        //     {"project13":"2,34,675"},
        //     {"project14":"4,78,989"},
        //     {"project15":"11,34,234"}
        //   ]
        //   this.cards=projectcards;
          
        // }
        // else if(type == "Application"){
        //   let projectcards=[
        //     {"App1":"1,24,293"},
        //     {"App2":"18,000"},
        //     {"App3":"2,34,675"},
        //     {"APp3":"4,78,989"},
        //     {"App4":"11,34,234"}
        //   ]
        //   this.cards=projectcards;
          
        // }else{
        //   let projectcards=[
        //     {"Model1":"1,24,293"},
        //     {"model23":"18,000"},
        //     {"model24":"2,34,675"},
        //     {"model25":"4,78,989"},
        //     {"model236":"11,34,234"}
        //   ]
        //   this.cards=projectcards;

        // }

        this._service.postData("/cards",{type:type,user_id:this.userId}).subscribe((data=>{
          this.cards= data['cards'];
          this.dashboard=true;
        }))

        
        
      }

      //----------------------------adding new item---------------------------->

      addNewItem(type){
        let userInput;

        if(this.type == "Model"){
          // this._dialog.open(AddFormComponent,{panelClass: 'myapp-no-padding-dialog',
          //           data: {
          //             crud:"Add",
          //             type: this.type
          //           },
          //           height: '320px',
          //           width: '400px',
          //         });
            this._router.navigate(['/initial'])
        }
        else if(this.type == "User"){
          const dialogRef=this._dialog.open(AddFormComponent,{panelClass: 'myapp-no-padding-dialog',
                    data: {
                      crud:"Add",
                      type: this.type
                    },
                    height: '550px',
                    width: '500px',
                  });

                  dialogRef.afterClosed().subscribe(result => {
                    console.log('The dialog was closed');
                    console.log(result)
                    userInput=result;
                    userInput["type"]=this.type;
                    userInput["user_id"]=this.userId;
                    
                    this._service.postData("/add",userInput).subscribe(result => {
                      console.log(result);
                    })
                  });

        }
        
        else{
          const dialogRef= this._dialog.open(AddFormComponent,{panelClass: 'myapp-no-padding-dialog',
                    data: {
                      crud:"Add",
                      type: this.type
                    },
                    height: '320px',
                    width: '400px',
                  });

                  dialogRef.afterClosed().subscribe(result => {
                    console.log('The dialog was closed');
                    console.log(result)
                     userInput=result;

                          userInput["type"]=this.type;
                        userInput["user_id"]=this.userId;

                        if(this.type == "Application"){
                          userInput["application_id"]=this.currentApplicationId;
                          userInput["project_id"]=this.currentProjectId
                        }else{
                          userInput["project_id"]=this.currentProjectId
                        }
                        console.log("checking user input to backend");
                        console.log(userInput);
                        
                        this._service.postData("/add",userInput).subscribe(result => {
                          console.log(result);
                        })
                  });
            }

     }

      //----------------------------end of adding new item---------------------------->

       //----------------------------viewing  item---------------------------->
      viewRow(row){

        if(this.type=="Project"){
          this.displayedColumns=['application_id', 'application_name', 'created_by','project_name'];
          this.columnsToDisplay=  this.displayedColumns.concat(['myExtraColumn']);
    
          this.currentProjectId=row.project_id
    
        let dataToBackend={
          type:"Application",
          user_id:this.userId,
          project_id:this.currentProjectId
    
        }
        this._service.postData("/view",dataToBackend).subscribe(data=>{
          console.log(data["applicationData"]);
         this.applicationData=data["applicationData"];
         this.data=this.applicationData;
         this.dataSource = new MatTableDataSource(this.data);
         this.dataSource.paginator = this.paginator;
        this.dataSource.sort = this.sort;
         this.type="Application";
        })
         
      }
        else if (this.type =="Application"){
          // this.displayedColumns=['model_id','model_name','created_by','E','T','H','I','C','A'];
          this.displayedColumns = ['name',"type","status","criteria","E","T","H","I","C","A","Total", 'Actions'];

          this.columnsToDisplay=  this.displayedColumns.concat(['myExtraColumn']);
          this.currentApplicationId=row.application_id;
    
            let dataToBackend={
              type:"Model",
              user_id:this.userId,
              project_id:this.currentProjectId,
              application_id:this.currentApplicationId
            }
    
            this._service.postData("/view",dataToBackend).subscribe(data=>{
                console.log(data["modelData"]);
               this.modelData=data["modelData"];
               this.DATA=this.modelData;
              //  this.DATA=[
              //   {
              //     "name": "model1",
              //     "type":"type1",
              //     "status":"training Actions",
              //     "criteria":"Weightage",
              //     "E":"10%",
              //     "T":"20%",
              //     "H":"30%",
              //     "I":"50%",
              //     "C":"34%",
              //     "A":"34%",
              //     "Total":"90%",
              //     "id": 1,
              //     "title": "delectus aut autem",
                 
              //     "Actions": false
              //   },
              //   {
              //     "name": "model1",
              //     "type":"type1",
              //     "status":"training Actions",
              //     "E":"10",
              //     "T":"20",
              //     "H":"30",
              //     "I":"50",
              //     "C":"34",
              //     "A":"34",
              //     "Total":"90",
              //     "id": 1,
              //     "title": "delectus aut autem",
              //     "criteria":"Score",
              //     "Actions": false
              //   },
              //   {
              //     "name": "model2",
              //     "type":"type2",
              //     "status":"training done",
              //     "E":"10%",
              //     "T":"20%",
              //     "H":"30%",
              //     "I":"50%",
              //     "C":"34%",
              //     "A":"34%",
              //     "Total":"90%",
              //     "id": 2,
              //     "title": "delectus aut autem",
              //     "criteria":"Weightage",
              //     "Actions": true
              //   },
              //   {
              //     "name": "model2",
              //     "type":"type2",
              //     "status":"training done",
              //     "E":"10",
              //     "T":"20",
              //     "H":"30",
              //     "I":"50",
              //     "C":"34",
              //     "A":"34",
              //     "Total":"90",
              //     "id": 2,
              //     "title": "delectus aut autem",
              //     "criteria":"Score",
              //     "Actions": true
              //   }
              // ]
               this.dataSource = new MatTableDataSource(this.DATA);
               this.dataSource.paginator = this.paginator;
               this.dataSource.sort = this.sort;

               this.spanRow('name', d => d.name);
               this.spanRow('type', d => d.type);
               this.spanRow('status', d => d.status);
               this.spanRow('Actions', d => d.Actions);
               this.type="Model";
              })
            
          }
          else if(this.type == "User"){
            let dataToBackend={
              type:"User",
              user_id:this.userId,
            }
            
          }
          else{
            this.currentModelId=row.model_id;
            let dataToBackend={
              type:"Model",
              user_id:this.userId,
              project_id:this.currentProjectId,
              application_id:this.currentApplicationId,
              model_id:this.currentModelId
            }
            console.log(dataToBackend);
    
            this._service.postData("/fetch_ethica_score",dataToBackend).subscribe(oldWeightages=>{
               this.oldWeightages=oldWeightages;
               for (let key in dataToBackend){
                this.oldWeightages[key]=dataToBackend[key];
              }
              console.log(this.oldWeightages);
              
              this._service.postData("/recalculate_ethica_score",this.oldWeightages).subscribe(scoreData =>{
               
                console.log(scoreData);
                this._service.setScoreData(scoreData);
                this._router.navigate(["/score"],{ state: { type:"Model",
                        user_id:this.userId,
                        project_id:this.currentProjectId,
                        application_id:this.currentApplicationId,
                        model_id:this.currentModelId } 
                      }
              );
                
              })
            });
    
            
          }
      
    }

      //----------------------------end of viewing new item---------------------------->


     backToTables(){
       console.log("back to tables is called");
       if(this.type == "Application"){
        this.displayedColumns=['project_id', 'project_name','created_by','group_id'];
        this.columnsToDisplay=  this.displayedColumns.concat(['myExtraColumn']);
         console.log(this.projectData);
         this.data=this.projectData;
         this.dataSource = new MatTableDataSource(this.data);
          this.dataSource.paginator = this.paginator;
          this.dataSource.sort = this.sort;
          this.type = "Project";

       }else if(this.type == "Model"){
        this.displayedColumns=['application_id', 'application_name', 'created_by','project_name'];
        this.columnsToDisplay=  this.displayedColumns.concat(['myExtraColumn']);
       
         this.data=this.applicationData;
         this.dataSource = new MatTableDataSource(this.data);
         this.dataSource.paginator = this.paginator;
        this.dataSource.sort = this.sort;
         this.type = "Application"
       }
     }

     tabClick(tab,type) {
      console.log(tab);
      console.log(type);
      this.viewDashboard(type);
    }

     extractWeightage(oldScore){
       for(let letter in oldScore) {
         if(letter != "ETHICA_Score"){
          let subParams:any[]=[];
          let subParamsList:any[]=[]
           for (let param in oldScore[letter]){
            
             if(param == "Weightage"){
               switch(letter){
                 case "E": this.ETHICA[0]=oldScore[letter][param];
                 case "T": this.ETHICA[1]=oldScore[letter][param];
                 case "H": this.ETHICA[2]=oldScore[letter][param];
                 case "I": this.ETHICA[3]=oldScore[letter][param];
                 case "C": this.ETHICA[4]=oldScore[letter][param];
                 case "A": this.ETHICA[5]=oldScore[letter][param];
               }
              
             }
             if(param == "Features"){
               
                oldScore[letter][param].forEach(feature =>{
                    for (let subparam in feature){
                        console.log(feature[subparam]);
                        subParamsList.push(subparam)
                        subParams.push(feature[subparam]["Weightage"])
                    }
                })
             }
             this.subparameters[letter]=subParams;
             this.subparameterslist[letter]=subParamsList;
            
           }
         }
       }
     }



     spanRow(key, accessor) {
      for (let i = 0; i < this.DATA.length;) {
        let currentValue = accessor(this.DATA[i]);
        let count = 1;
  
        // Iterate through the remaining rows to see how many match
        // the current value as retrieved through the accessor.
        for (let j = i + 1; j < this.DATA.length; j++) {
          if (currentValue != accessor(this.DATA[j])) {
            break;
          }
  
          count++;
        }
  
        if (!this.spans[i]) {
          this.spans[i] = {};
        }
  
        // Store the number of similar values that were found (the span)
        // and skip i to the next unique row.
        this.spans[i][key] = count;
        i += count;
      }
    }
  
    getRowSpan(col, index) {
      return this.spans[index] && this.spans[index][col];
    }
  
    selectedRow: any;
  
    selectedRowIndex: number;
  
    highlight(row) {
      this.selectedRowIndex = row.id;
    }
        

}




/*let modelData=[{
          "id": "1",
          "name": "Model1",
          "progress": "69",
          "color": "fuchsia"
        },
        {
          "id": "2",
          "name": "model2",
          "progress": "96",
          "color": "teal"
        },
        {
          "id": "3",
          "name": "model3",
          "progress": "33",
          "color": "teal"
        },
        {
          "id": "4",
          "name": "Model1",
          "progress": "69",
          "color": "fuchsia"
        },
        {
          "id": "5",
          "name": "model2",
          "progress": "96",
          "color": "teal"
        },
        {
          "id": "6",
          "name": "model3",
          "progress": "33",
          "color": "teal"
        },
        {
          "id": "7",
          "name": "Model1",
          "progress": "69",
          "color": "fuchsia"
        },
        {
          "id": "8",
          "name": "model2",
          "progress": "96",
          "color": "teal"
        },
        {
          "id": "9",
          "name": "model3",
          "progress": "33",
          "color": "teal"
        }]


        let applicationData=[{
          "id": "1",
          "name": "app1",
          "progress": "69",
          "color": "fuchsia"
        },
        {
          "id": "2",
          "name": "app2",
          "progress": "96",
          "color": "teal"
        },
        {
          "id": "3",
          "name": "app3",
          "progress": "33",
          "color": "teal"
        },{
          "id": "4",
          "name": "app4",
          "progress": "96",
          "color": "teal"
        },
        {
          "id": "5",
          "name": "app5",
          "progress": "33",
          "color": "teal"
        },
        {
          "id": "6",
          "name": "app4",
          "progress": "96",
          "color": "teal"
        },
        {
          "id": "7",
          "name": "app5",
          "progress": "33",
          "color": "teal"
        }] */