import { Component, OnInit, Input } from '@angular/core';

@Component({
  selector: 'app-bar',
  templateUrl: './bar.component.html',
  styleUrls: ['./bar.component.css']
})
export class BarComponent implements OnInit {

  constructor() { }
  @Input() temp : Array<any>=[]; 
  
  public flag : Array<number>=[];
  public width : number;
  public height : number;
  public padding : number;
  @Input() public factor : number;
  ngOnInit(): void {
    // if(this.temp["type"]=="BarChart_1")
    // {
    //   this.factor=0.25;
    // }
    // else
    // {
    //   this.factor=0.40;
    // }
    this.width=this.factor*window.innerWidth;
    this.height=0.5*window.innerHeight;
    this.padding=0.05*this.width;
    //var x=this.temp["rand"];
    for(let i=0;i<this.temp["data"].length;i++)
    {
      this.flag.push(this.temp["data"][i]);
      // this.labels.push(this.temp["data"][i].name);
    }
     
  }
  public options = {
    scaleShowVerticalLines: false,
    responsive: true
  };
  public type = 'bar';
  public labels = ['2006', '2007', '2008', '2009', '2010', '2011', '2012','2013','2014','2015'];
  public data = [
    {data: this.flag, label: 'Series A'}
  ];
}
