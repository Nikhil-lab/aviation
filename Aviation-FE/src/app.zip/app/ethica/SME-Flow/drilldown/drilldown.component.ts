import { Component, ViewChild, ViewContainerRef, ComponentFactoryResolver, ComponentRef, ComponentFactory,OnInit } from '@angular/core';
import { HelloComponent } from 'src/app/hello.component';
import { PieComponent } from './pie/pie.component';
import { DonutComponent } from './donut/donut.component';
import { ScatterComponent } from './scatter/scatter.component';
import { LineComponent } from './line/line.component';
import { AreaComponent } from './area/area.component';
import { LollipopComponent } from './lollipop/lollipop.component';
import { RadarComponent } from './radar/radar.component';
import { PolorComponent } from './polor/polor.component';
import { BarComponent } from './bar/bar.component';
import { ActivatedRoute } from '@angular/router';
import { Observable } from 'rxjs';
import { map } from 'rxjs/operators';
import { ApiService } from '../../api/api.service';
import { HorizontalBarComponent } from './horizontal-bar/horizontal-bar.component';


@Component({
  selector: 'app-drilldown',
  templateUrl: './drilldown.component.html',
  styleUrls: ['./drilldown.component.css']
})
export class DrilldownComponent implements OnInit {

  cards;
//   paramsList=["Parameter1","Parameter2","Parameter3","Parameter4","Parameter5","Parameter6","Parameter8","parameter9","Parameters10","Parameters11","Parameters12"]
//    graphData=[

//         // first parameter
//             [{
//             "type" : "PieChart_1",
//             "data" : [
//                 {
//                     "name" : "action",
//                     "value" : 30
//                 },
//                 {
//                     "name" : "fiction",
//                     "value" : 15
//                 },
//                 {
//                     "name" : "horror",
//                     "value" : 10
//                 },
//                 {
//                     "name" : "fantasy",
//                     "value" : 20
//                 }
//             ]
//         },{
//             "type" : "RadarChart_2",
//             "data" : [
//                 {
//                     "name" : "action",
//                     "value" : 30
//                 },
//                 {
//                     "name" : "fiction",
//                     "value" : 15
//                 },
//                 {
//                     "name" : "horror",
//                     "value" : 10
//                 },
//                 {
//                     "name" : "fantasy",
//                     "value" : 20
//                 }
//             ]
//         },
//         {
//         "type" : "DoughnutChart_1",
//         "data" : [
//             {
//                 "name" : "action",
//                 "value" : 10
//             },
//             {
//                 "name" : "fiction",
//                 "value" : 14
//             },
//             {
//                 "name" : "horror",
//                 "value" : 12
//             },
//             {
//                 "name" : "fantasy",
//                 "value" : 8
//             }
//         ]
//         }
//         ],
//         // Second parameter
//         [{
//             "type" : "PolarChart_1",
//             "data" : [
//                 {
//                     "name" : "action",
//                     "value" : 30
//                 },
//                 {
//                     "name" : "fiction",
//                     "value" : 14
//                 },
//                 {
//                     "name" : "horror",
//                     "value" : 12
//                 },
//                 {
//                     "name" : "fantasy",
//                     "value" : 8
//                 },
//                 {
//                     "name" : "crime",
//                     "value" : 20            
//                 }
//             ]
//           },{
//             "type" : "LollipopChart_2",
//             "data" : [
//                 {
//                     "name" : "action",
//                     "value" : 30
//                 },
//                 {
//                     "name" : "fiction",
//                     "value" : 14
//                 },
//                 {
//                     "name" : "horror",
//                     "value" : 40
//                 },
//                 {
//                     "name" : "fantasy",
//                     "value" : 8
//                 },
//                 {
//                     "name" : "crime",
//                     "value" : 20            
//                 },
//                 {
//                     "name" : "mystery",
//                     "value" : 100
//                 }
//             ]
//           },{
//             "type" : "AreaChart_2",
//             "data" :[
//                 {
//                     "name" : 1,
//                     "value" : 43
//                 },
//                 {
//                     "name" : 2,
//                     "value" : 53
//                 },
//                 {
//                     "name" : 3,
//                     "value" : 50
//                 },
//                 {
//                     "name" : 4,
//                     "value" : 57
//                 },
//                 {
//                     "name" : 5,
//                     "value" : 59
//                 },
//                 {
//                     "name" : 6,
//                     "value" : 67
//                 }
//             ]
//         },{
//             "type" : "RadarChart_2",
//             "data" : [
//                 {
//                     "name" : "action",
//                     "value" : 30
//                 },
//                 {
//                     "name" : "fiction",
//                     "value" : 14
//                 },
//                 {
//                     "name" : "horror",
//                     "value" : 12
//                 },
//                 {
//                     "name" : "fantasy",
//                     "value" : 8
//                 }
//             ]
//         },{
//         "type" : "ScatterChart_2",
//         "data":[{
//             "y":"1.4",
//             "x":"23"
//             },
//             {
//             "y":"1.5",
//             "x":"29"
//             },
//             {
//             "y":"1.5",
//             "x":"33"
//             },
//             {
//             "y":"1.1",
//             "x":"41"
//             },
//             {
//             "y":"1.5",
//             "x":"47"
//             },
//             {
//             "y":"1.6",
//             "x":"49"
//             },
//             {
//             "y":"1.8",
//             "x":"51"
//             },
//             {
//             "y":"1.9",
//             "x":"53"
//             },
//             {
//             "y":"1.6",
//             "x":"57"
//             },
//             {
//             "y":"1.2",
//             "x":"58"
//             },
//             {
//             "y":"1.9",
//             "x":"61"
//             },
//             {
//             "y":"1.1",
//             "x":"63"
//             },
//             {
//             "y":"1.9",
//             "x":"64"
//             },{
//             "type" : "LineChart_1",
//             "data" :[
//                 {
//                     "name" : 1,
//                     "value" : 43
//                 },
//                 {
//                     "name" : 2,
//                     "value" : 53
//                 },
//                 {
//                     "name" : 3,
//                     "value" : 50
//                 },
//                 {
//                     "name" : 4,
//                     "value" : 57
//                 },
//                 {
//                     "name" : 5,
//                     "value" : 59
//                 },
//                 {
//                     "name" : 6,
//                     "value" : 67
//                 },
//                 {
//                     "name" : 7,
//                     "value" : 150
//                 }
//             ]
//             },
//             {
//             "y":"1.7",
//             "x":"71"
//             },
//             {
//             "y":"1.1",
//             "x":"77"
//             },
//             {
//             "y":"1.3",
//             "x":"79"
//             },
//             {
//             "y":"1.7",
//             "x":"83"
//             },
//             {
//             "y":"1.8",
//             "x":"89"
//             },
//             {
//             "y":"1.9",
//             "x":"91"
//             },
//             {
//             "y":"1.0",
//             "x":"93"
//             },
//             {
//                 "y":"1.7",
//                 "x" : "9"
//             }
//         ]
//         },{
//         "type" : "LineChart_1",
//         "data" :[
//             {
//                 "name" : 1,
//                 "value" : 43
//             },
//             {
//                 "name" : 2,
//                 "value" : 53
//             },
//             {
//                 "name" : 3,
//                 "value" : 50
//             },
//             {
//                 "name" : 4,
//                 "value" : 57
//             },
//             {
//                 "name" : 5,
//                 "value" : 59
//             },
//             {
//                 "name" : 6,
//                 "value" : 67
//             },
//             {
//                 "name" : 7,
//                 "value" : 150
//             }
//         ]
//         },
//         {
//         "type" : "PieChart_1",
//         "data" : [
//             {
//                 "name" : "Nikhil",
//                 "value" : 30
//             },
//             {
//                 "name" : "fiction",
//                 "value" : 15
//             },
//             {
//                 "name" : "horror",
//                 "value" : 10
//             },
//             {
//                 "name" : "fantasy",
//                 "value" : 20
//             }
//         ]
//         },{
//             "type" : "BarChart_2",
//             "data" :[
//                 100,200,300,400,500
//             ]
//           },
//         {
//         "type" : "DoughnutChart_1",
//         "data" : [
//             {
//                 "name" : "Nikhil",
//                 "value" : 10
//             },
//             {
//                 "name" : "fiction",
//                 "value" : 14
//             },
//             {
//                 "name" : "horror",
//                 "value" : 12
//             },
//             {
//                 "name" : "fantasy",
//                 "value" : 8
//             }
//         ]
//         }
//         ],
//         // third parameter
//         [{
//             "type" : "RadarChart_2",
//             "data" : [
//                 {
//                     "name" : "action",
//                     "value" : 30
//                 },
//                 {
//                     "name" : "fiction",
//                     "value" : 14
//                 },
//                 {
//                     "name" : "horror",
//                     "value" : 12
//                 },
//                 {
//                     "name" : "fantasy",
//                     "value" : 8
//                 }
//             ]
//         },{
//         "type" : "PieChart_1",
//         "data" : [
//             {
//                 "name" : "rajkumar",
//                 "value" : 30
//             },
//             {
//                 "name" : "fiction",
//                 "value" : 15
//             },
//             {
//                 "name" : "horror",
//                 "value" : 10
//             },
//             {
//                 "name" : "fantasy",
//                 "value" : 20
//             }
//         ]
//         },
//         {
//         "type" : "DoughnutChart_1",
//         "data" : [
//             {
//                 "name" : "Raj",
//                 "value" : 10
//             },
//             {
//                 "name" : "fiction",
//                 "value" : 14
//             },
//             {
//                 "name" : "horror",
//                 "value" : 12
//             },
//             {
//                 "name" : "fantasy",
//                 "value" : 8
//             }
//         ]
//         }
//         ],
//         // Forth parameter
//         [{
//         "type" : "LineChart_2",
//         "data" :[
//             {
//                 "name" : 1,
//                 "value" : 43
//             },
//             {
//                 "name" : 2,
//                 "value" : 53
//             },
//             {
//                 "name" : 3,
//                 "value" : 50
//             },
//             {
//                 "name" : 4,
//                 "value" : 57
//             },
//             {
//                 "name" : 5,
//                 "value" : 59
//             },
//             {
//                 "name" : 6,
//                 "value" : 67
//             },
//             {
//                 "name" : 7,
//                 "value" : 150
//             }
//         ]
//         },{
//         "type" : "PieChart_1",
//         "data" : [
//             {
//                 "name" : "rajkumar",
//                 "value" : 30
//             },
//             {
//                 "name" : "fiction",
//                 "value" : 15
//             },
//             {
//                 "name" : "horror",
//                 "value" : 10
//             },
//             {
//                 "name" : "fantasy",
//                 "value" : 20
//             }
//         ]
//         },
//         {
//         "type" : "DoughnutChart_1",
//         "data" : [
//             {
//                 "name" : "Raj",
//                 "value" : 10
//             },
//             {
//                 "name" : "fiction",
//                 "value" : 14
//             },
//             {
//                 "name" : "horror",
//                 "value" : 12
//             },
//             {
//                 "name" : "fantasy",
//                 "value" : 8
//             }
//         ]
//         },
//         {
//         "type" : "PieChart_1",
//         "data" : [
//             {
//                 "name" : "pretty well",
//                 "value" : 30
//             },
//             {
//                 "name" : "fiction",
//                 "value" : 15
//             },
//             {
//                 "name" : "horror",
//                 "value" : 10
//             },
//             {
//                 "name" : "fantasy",
//                 "value" : 20
//             }
//         ]
//         },
//         {
//         "type" : "DoughnutChart_1",
//         "data" : [
//             {
//                 "name" : "Working",
//                 "value" : 10
//             },
//             {
//                 "name" : "fiction",
//                 "value" : 14
//             },
//             {
//                 "name" : "horror",
//                 "value" : 12
//             },
//             {
//                 "name" : "fantasy",
//                 "value" : 8
//             }
//         ]
//         }
//         ],
//         // Fifth parameter
//         [{
//             "type" : "AreaChart_2",
//             "data" :[
//                 {
//                     "name" : 1,
//                     "value" : 43
//                 },
//                 {
//                     "name" : 2,
//                     "value" : 53
//                 },
//                 {
//                     "name" : 3,
//                     "value" : 50
//                 },
//                 {
//                     "name" : 4,
//                     "value" : 57
//                 },
//                 {
//                     "name" : 5,
//                     "value" : 59
//                 },
//                 {
//                     "name" : 6,
//                     "value" : 67
//                 }
//             ]
//         }],
//         // Sixth parameter
//         [{
//             "type" : "LollipopChart_2",
//             "data" : [
//                 {
//                     "name" : "action",
//                     "value" : 30
//                 },
//                 {
//                     "name" : "fiction",
//                     "value" : 14
//                 },
//                 {
//                     "name" : "horror",
//                     "value" : 40
//                 },
//                 {
//                     "name" : "fantasy",
//                     "value" : 8
//                 },
//                 {
//                     "name" : "crime",
//                     "value" : 20            
//                 },
//                 {
//                     "name" : "mystery",
//                     "value" : 100
//                 }
//             ]
//         }] ,
//         // Seventh parameter
//         [
//         {
//         "type" : "PolarChart_1",
//         "data" : [
//                 {
//         "name" : "action",
//         "value" : 30
//                 },
//                 {
//         "name" : "fiction",
//         "value" : 14
//                 },
//                 {
//         "name" : "horror",
//         "value" : 12
//                 },
//                 {
//         "name" : "fantasy",
//         "value" : 8
//                 },
//                 {
//         "name" : "crime",
//         "value" : 20
//                 }
//             ]
//         }
        
//         ] ,
//         // Eight parameter
//         [{
//             "type" : "RadarChart_1",
//             "data" : [
//                 {
//                     "name" : "action",
//                     "value" : 30
//                 },
//                 {
//                     "name" : "fiction",
//                     "value" : 14
//                 },
//                 {
//                     "name" : "horror",
//                     "value" : 12
//                 },
//                 {
//                     "name" : "fantasy",
//                     "value" : 8
//                 }
//             ]
//         },{
//             "type" : "PolarChart_1",
//             "data" : [
//                 {
//                     "name" : "action",
//                     "value" : 30
//                 },
//                 {
//                     "name" : "fiction",
//                     "value" : 14
//                 },
//                 {
//                     "name" : "horror",
//                     "value" : 12
//                 },
//                 {
//                     "name" : "fantasy",
//                     "value" : 8
//                 },
//                 {
//                     "name" : "crime",
//                     "value" : 20            
//                 }
//             ]
//           }],
//           //9th
//           [
//             {
//             "type" : "PolarChart_1",
//             "data" : [
//                     {
//             "name" : "action",
//             "value" : 30
//                     },
//                     {
//             "name" : "fiction",
//             "value" : 14
//                     },
//                     {
//             "name" : "horror",
//             "value" : 12
//                     },
//                     {
//             "name" : "fantasy",
//             "value" : 8
//                     },
//                     {
//             "name" : "crime",
//             "value" : 20
//                     }
//                 ]
//             }
            
//             ] ,
//             // 10th parameter
//             [{
//                 "type" : "RadarChart_1",
//                 "data" : [
//                     {
//                         "name" : "action",
//                         "value" : 30
//                     },
//                     {
//                         "name" : "fiction",
//                         "value" : 14
//                     },
//                     {
//                         "name" : "horror",
//                         "value" : 12
//                     },
//                     {
//                         "name" : "fantasy",
//                         "value" : 8
//                     }
//                 ]
//             },{
//                 "type" : "PolarChart_1",
//                 "data" : [
//                     {
//                         "name" : "action",
//                         "value" : 30
//                     },
//                     {
//                         "name" : "fiction",
//                         "value" : 14
//                     },
//                     {
//                         "name" : "horror",
//                         "value" : 12
//                     },
//                     {
//                         "name" : "fantasy",
//                         "value" : 8
//                     },
//                     {
//                         "name" : "crime",
//                         "value" : 20            
//                     }
//                 ]
//               }],
//               //11th
//               [{
//                 "type" : "RadarChart_1",
//                 "data" : [
//                     {
//                         "name" : "action",
//                         "value" : 30
//                     },
//                     {
//                         "name" : "fiction",
//                         "value" : 14
//                     },
//                     {
//                         "name" : "horror",
//                         "value" : 12
//                     },
//                     {
//                         "name" : "fantasy",
//                         "value" : 8
//                     }
//                 ]
//             },{
//                 "type" : "PolarChart_1",
//                 "data" : [
//                     {
//                         "name" : "action",
//                         "value" : 30
//                     },
//                     {
//                         "name" : "fiction",
//                         "value" : 14
//                     },
//                     {
//                         "name" : "horror",
//                         "value" : 12
//                     },
//                     {
//                         "name" : "fantasy",
//                         "value" : 8
//                     },
//                     {
//                         "name" : "crime",
//                         "value" : 20            
//                     }
//                 ]
//               }]
//              ]
  name = 'Angular';
  state$: Observable<object>;
  type:string;
  factor;
  paramsList=[];
  graphData=[];
  
  @ViewChild('container', { static: true, read: ViewContainerRef }) entry: ViewContainerRef;
  componentRef:any;
  constructor(private resolver: ComponentFactoryResolver,public activatedRoute: ActivatedRoute, private _service:ApiService) { }

  ngOnInit(): void {

    this.state$ = this.activatedRoute.paramMap
      .pipe(map(() => window.history.state,
        console.log(window.history.state)
        ))

    this.state$.subscribe(data=>{
      console.log("state data");
      console.log(data['data']);
      this.type=data['data'];
    })

    this._service.postData("/subParamtersGraph",{type:this.type}).subscribe(data=>{
        console.log(data);
        this.paramsList=data["paramsList"];
        this.graphData=data["graphData"];

        let comp=this.graphData[0];
        let com:any;
          for(var i=0;i<comp.length;i++)
          { 
              var x = comp[i].type;
              switch(x.charAt(x.length-1))
              { 
                  case '1' : 
                  this.factor = 0.25;
                  break;
                case '2' :
                  this.factor = 0.5;
                  break;
                case '3' :
                  this.factor =0.9;
                  break;
                default : 
                  break;
              }
            
                
              if(comp[i].type=="PieChart_1" || comp[i].type=="PieChart_2" || comp[i].type=="PieChart_3")
              com=PieComponent;
              else if(comp[i].type=="DoughnutChart_1" || comp[i].type=="DoughnutChart_2" || comp[i].type=="DoughnutChart_3")
              com=DonutComponent;
              else if(comp[i].type=="ScatterChart_1" || comp[i].type=="ScatterChart_2" || comp[i].type=="ScatterChart_3")
              com=ScatterComponent;
              else if(comp[i].type=="LineChart_1" || comp[i].type=="LineChart_2" || comp[i].type=="LineChart_3")
              com=LineComponent;
              else if(comp[i].type=="AreaChart_1" || comp[i].type=="AreaChart_2" || comp[i].type=="AreaChart_3")
              com=AreaComponent;
              else if(comp[i].type=="LollipopChart_1" || comp[i].type=="LollipopChart_2" || comp[i].type=="LollipopChart_3")
              com=LollipopComponent;
              else if(comp[i].type=="PolarChart_1" || comp[i].type=="PolarChart_2" || comp[i].type=="PolarChart_3")
              com=PolorComponent;
              else if(comp[i].type=="RadarChart_2" || comp[i].type=="RadarChart_2" || comp[i].type=="RadarChart_3")
              com=RadarComponent;
              else if(comp[i].type=="BarChart_2" || comp[i].type=="BarChart_1" || comp[i].type=="BarChart_3")
              com=BarComponent;
              else if(comp[i].type=="HorizontalBarChart_2" || comp[i].type=="HorizontalBarChart_1" || comp[i].type=="HorizontalBarChart_3")
              com=HorizontalBarComponent;
                else
                continue;
             const factory1 = this.resolver.resolveComponentFactory(com);
              this.componentRef=this.entry.createComponent(factory1);
              this.componentRef.instance.temp = comp[i];
              this.componentRef.instance.factor = this.factor;
          }
    })

    let projectcards=[
          {"App1":"1,24,293"},
          {"App2":"18,000"},
          {"App3":"2,34,675"},
          {"APp3":"4,78,989"},
          {"App4":"11,34,234"}
        ]
        this.cards=projectcards;

        

        this.entry.clear();
    // const factory = this.resolver.resolveComponentFactory(HelloComponent);
    // const componentRef = this.entry.createComponent(factory);
    // componentRef.instance.name = this.name;



 

    }


    tabClick(event){
      let data;
      this.entry.clear();
      console.log(event.index)
      this.createComponents(this.graphData[event.index]);
    }

    createComponents(comp : Array<any>)
  {
var com : any;
for(var i=0;i<comp.length;i++)
    {
        var x = comp[i].type;
        switch(x.charAt(x.length-1))
        { 
            case '1' : 
            this.factor = 0.25;
            break;
          case '2' :
            this.factor = 0.50;
            break;
          case '3' :
            this.factor =0.9;
            break;
          default : 
            break;
        }

        if(comp[i].type=="PieChart_1" || comp[i].type=="PieChart_2" || comp[i].type=="PieChart_3")
        com=PieComponent;
        else if(comp[i].type=="DoughnutChart_1" || comp[i].type=="DoughnutChart_2" || comp[i].type=="DoughnutChart_3")
        com=DonutComponent;
        else if(comp[i].type=="ScatterChart_1" || comp[i].type=="ScatterChart_2" || comp[i].type=="ScatterChart_3")
        com=ScatterComponent;
        else if(comp[i].type=="LineChart_1" || comp[i].type=="LineChart_2" || comp[i].type=="LineChart_3")
        com=LineComponent;
        else if(comp[i].type=="AreaChart_1" || comp[i].type=="AreaChart_2" || comp[i].type=="AreaChart_3")
        com=AreaComponent;
        else if(comp[i].type=="LollipopChart_1" || comp[i].type=="LollipopChart_2" || comp[i].type=="LollipopChart_3")
        com=LollipopComponent;
        else if(comp[i].type=="PolarChart_1" || comp[i].type=="PolarChart_2" || comp[i].type=="PolarChart_3")
        com=PolorComponent;
        else if(comp[i].type=="RadarChart_2" || comp[i].type=="RadarChart_2" || comp[i].type=="RadarChart_3")
        com=RadarComponent;
        else if(comp[i].type=="BarChart_2" || comp[i].type=="BarChart_1" || comp[i].type=="BarChart_3")
          com=BarComponent;
        else if(comp[i].type=="HorizontalBarChart_2" || comp[i].type=="HorizontalBarChart_1" || comp[i].type=="HorizontalBarChart_3")
        com=HorizontalBarComponent;
        else
        continue;

      
   const factory1 = this.resolver.resolveComponentFactory(com);
   this.componentRef=this.entry.createComponent(factory1);
   this.componentRef.instance.temp = comp[i];
   this.componentRef.instance.factor = this.factor;
    }
  }
  


  


}
