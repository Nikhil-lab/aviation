import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class Globals {

  constructor() { }
  generateId(prefix : string){
    return Math.random().toString(36).replace('0.',prefix || '');
}

}
