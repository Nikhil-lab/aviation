import { Component, OnInit,Input } from '@angular/core';
import * as d3 from 'd3';

import {axisBottom,axisLeft} from 'd3';
import { Globals } from '../globals.service';


@Component({
  selector: 'app-line',
  templateUrl: './line.component.html',
  styleUrls: ['./line.component.css']
})
export class LineComponent implements OnInit {

  constructor(private globals : Globals) { }
  @Input() temp : Array<any>=[];
  @Input() public factor : number;
  public width : number;
  public height : number;
  public padding : number;
  public obj : Array<any>=[];
  public flag : Array<number>=[];
  public labels : Array<any>=[];
  public id : string;
  ngOnInit(): void {
    this.id = this.globals.generateId("myChart");
    // if(this.temp["type"]=="LineChart_1")
    // {
    //   this.factor=0.25;
    // }
    // else
    // {
    //   this.factor=0.45;
    // }
    this.width=this.factor*window.innerWidth;
    this.height=0.5*window.innerHeight;
    this.padding=0.05*this.width;
    for(let i=0;i<this.temp["data"].length;i++)
    {
        this.flag.push(this.temp["data"][i].value);
        this.labels.push(this.temp["data"][i].name);
        this.obj.push(this.temp["data"][i]);
    }    
  }
  ngAfterViewInit(){
    var margin = { top : 30, bottom : 30, left : 30, right : 30};
    var x = this.width - margin.left - margin.right;
    var y = this.height - margin.top - margin.bottom;
    var svg = d3.select("#"+this.id)
    .append('svg')
    .attr('width',this.width)
    .attr('height',this.height)
    .append('g')
    .attr('transform',"translate("+margin.left+","+margin.top+")");   
    var xScale = d3.scaleLinear()
    .domain([0,d3.max(this.labels)])
    .range([0,x]);
    var yScale = d3.scaleLinear()
    .domain([0,d3.max(this.flag)])
    .range([y,0]); 
    svg.append('g')
    .attr("transform","translate(0,"+y+")")
    .call(axisBottom(xScale));
    svg.append('g').call(axisLeft(yScale));
    console.log(this.obj);
    svg.append('path')
    .datum(this.obj)
    .attr('fill','none')
    .attr('stroke','lightblue')
    .attr('stroke-width',3)
    .attr('d',d3.line()
    .x(function(d){return xScale(d['name']);})
    .y(function(d){return yScale(d['value']);}));
    svg.selectAll('myCircles')
    .data(this.obj)
    .enter()
    .append('circle')
    .attr('fill','brown')
    .attr('cx',function(d){ return xScale(d.name);})
    .attr('cy',function(d){ return yScale(d.value);})
    .attr('r',2);
  }
}
