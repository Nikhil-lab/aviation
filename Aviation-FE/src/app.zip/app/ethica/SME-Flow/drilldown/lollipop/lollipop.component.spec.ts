import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { LollipopComponent } from './lollipop.component';

describe('LollipopComponent', () => {
  let component: LollipopComponent;
  let fixture: ComponentFixture<LollipopComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ LollipopComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(LollipopComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
