import { Component, OnInit,Input } from '@angular/core';
import * as d3 from 'd3';
import { axisBottom, axisLeft } from 'd3';
import { Globals } from '../globals.service';


@Component({
  selector: 'app-lollipop',
  templateUrl: './lollipop.component.html',
  styleUrls: ['./lollipop.component.css']
})
export class LollipopComponent implements OnInit {

  @Input() temp : Array<any>; 
  constructor(private globals : Globals) { }
  @Input() public factor : number;
  public width : number;
  public height : number;
  public padding : number;
  public id : string;
  public labels : Array<any>=[];
  public flag : Array<number>=[];
  public obj : Array<any>=[];
  ngOnInit(): void {
    this.id=this.globals.generateId("myChart");
    // if(this.temp["type"]=="LollipopChart_1")
    // {
    //   this.factor=0.25;
    // }
    // else
    // {
    //   this.factor=0.40;
    // }
    this.width=this.factor*window.innerWidth;
    this.height=0.5*window.innerHeight;
    this.padding=0.05*this.width;
    for(let i=0;i<this.temp["data"].length;i++)
    {
      this.flag.push(this.temp["data"][i].value);
      this.labels.push(this.temp["data"][i].name);
      this.obj.push(this.temp["data"][i]);
    }
    var str :string =this.id;
    console.log(str);
  }
  ngAfterViewInit(){
    var margin = {top:30, right:30, bottom:30, left: 30},
    x = this.width - margin.left - margin.right,
    y = this.height - margin.top - margin.bottom;
    var svg = d3.select("#"+this.id)
    .append("svg")
    .attr("width",this.width)
    .attr("height",this.height)
    .append('g')
    .attr('transform',"translate("+margin.left+","+margin.top+")");
    var xScale = d3.scaleBand()
    .domain(this.labels)
    .range([0,x])
    .padding(1);
    var yScale = d3.scaleLinear()
    .domain([0,d3.max(this.flag)])
    .range([y,0]);
    svg.append('g')
    .attr("transform","translate(0,"+y+")")
    .call(axisBottom(xScale));
    svg.append('g').call(axisLeft(yScale));
    svg.selectAll("myline")
    .data(this.obj)
    .enter()
    .append("line")
      .attr("y2", function(d) { return yScale(d.value); })
      .attr("y1", yScale(0))
      .attr("x1", function(d) { return xScale(d.name); })
      .attr("x2", function(d) { return xScale(d.name); })
      .attr("stroke", "maroon");
      svg.selectAll("mycircle")
  .data(this.obj)
  .enter()
  .append("circle")
    .attr("cx", function(d) { return xScale(d.name); })
    .attr("cy", function(d) { return yScale(d.value); })
    .attr("r", "4")
    .style("fill", "#69b3a2")
    .attr("stroke", "black");
  }
}
