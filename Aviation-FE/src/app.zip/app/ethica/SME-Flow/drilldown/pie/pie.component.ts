import { Component, OnInit, Input } from '@angular/core';

@Component({
  selector: 'app-pie',
  templateUrl: './pie.component.html',
  styleUrls: ['./pie.component.css']
})
export class PieComponent implements OnInit {

  @Input() temp :Array<any>;
  constructor() { }
  public type="pie";
  public labels : Array<any>=[];
  public data : Array<any>=[];
  @Input() public factor : number;
  public width : number;
  public height : number;
  public padding : number;
  ngOnInit(): void {
    console.log("pie data")
    console.log(this.temp);
    // if(this.temp["type"]=="PieChart_1")
    // {
    //   this.factor=0.25;
    // }
    // else
    // {
    //   this.factor=0.45;
    // }
    this.width=this.factor*window.innerWidth;
    this.height=0.5*window.innerHeight;
    this.padding=0.05*this.width;
    for(let i=0;i<this.temp["data"].length;i++)
    {
      this.labels.push(this.temp["data"][i].name);
      this.data.push(this.temp["data"][i].value);
    }
  }
}
