import { Component, OnInit, Input } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-polor',
  templateUrl: './polor.component.html',
  styleUrls: ['./polor.component.css']
})
export class PolorComponent implements OnInit {

  @Input() temp : Array<any>;
  constructor(private _router: Router) { }
  public type="polarArea";
  public labels : Array<any>=[];
  public data : Array<any>=[];
  @Input() public factor : number;
  public width : number;
  public height : number;
  public padding : number;

  Id;
  ngOnInit(): void {
  // if(this.temp["type"]=="PolarChart_1")
  //   {
  //     this.factor=0.25;
  //   }
  //   else
  //   {
  //     this.factor=0.40;
  //   }
    this.width=this.factor*window.innerWidth;
    this.height=0.5*window.innerHeight;
    this.padding=0.05*this.width;

    if(this.temp["Id"]){
      this.Id=this.temp["Id"];
    }
    for(let i=0;i<this.temp["data"].length;i++)
    {
      this.labels.push(this.temp["data"][i].name);
      this.data.push(this.temp["data"][i].value);
    }
  }


  nextDynamicPage(){
    this._router.navigate(['/secondleveldrilldown']);
    console.log("nextDynamicPage opened")
    console.log(this.Id)
  }
 
}