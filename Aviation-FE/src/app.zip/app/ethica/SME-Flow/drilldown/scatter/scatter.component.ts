import { Component, OnInit, Input } from '@angular/core';
import * as d3 from 'd3';

import {axisBottom,axisLeft} from 'd3';
import { Globals } from '../globals.service';

@Component({
  selector: 'app-scatter',
  templateUrl: './scatter.component.html',
  styleUrls: ['./scatter.component.css']
})
export class ScatterComponent implements OnInit {

  constructor(private globals : Globals) { }
  @Input() temp : Array<any>=[];
  public factor : number;
  public width : number;
  public height : number;
  public padding : number;
  public obj : Array<any>=[];
  public flag : Array<number>=[];
  public labels : Array<any>=[];
  public id : string;
  ngOnInit(): void {
    this.id = this.globals.generateId("myChart");
    if(this.temp["type"]=="ScatterChart_1")
    {
      this.factor=0.25;
    }
    else
    {
      this.factor=0.40;
    }
    this.width=this.factor*window.innerWidth;
    this.height=0.5*window.innerHeight;
    this.padding=0.05*this.width;
    for(let i=0;i<this.temp["data"].length;i++)
    {
        this.flag.push(this.temp["data"][i].y);
        this.labels.push(this.temp["data"][i].x);
        this.obj.push(this.temp["data"][i]);
    }    
  }
  ngAfterViewInit(){
    var margin = { top : 30, bottom : 30, left : 30, right : 30};
    var x = this.width - margin.left - margin.right;
    var y = this.height - margin.top - margin.bottom;
    var svg = d3.select("#"+this.id)
    .append('svg')
    .attr('width',this.width)
    .attr('height',this.height)
    .append('g')
    .attr('transform',"translate("+margin.left+","+margin.top+")");   
    var xScale = d3.scaleLinear()
    .domain([0,d3.max(this.labels)])
    .range([0,x]);
    var yScale = d3.scaleLinear()
    .domain([d3.min(this.flag),d3.max(this.flag)])
    .range([y,0]); 
    svg.append('g')
    .attr("transform","translate(0,"+y+")")
    .call(axisBottom(xScale));
    svg.append('g').call(axisLeft(yScale));
    svg.selectAll("dot")
    .data(this.obj)
    .enter()
    .append('circle')
    .attr('fill','brown')
    .attr('r',3)
    .attr('cx',function(d){return xScale(d.x);})
    .attr('cy',function(d){return yScale(d.y);});
  }
}
