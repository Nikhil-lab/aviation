import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SecondLevelDrilldownComponent } from './second-level-drilldown.component';

describe('SecondLevelDrilldownComponent', () => {
  let component: SecondLevelDrilldownComponent;
  let fixture: ComponentFixture<SecondLevelDrilldownComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SecondLevelDrilldownComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SecondLevelDrilldownComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
