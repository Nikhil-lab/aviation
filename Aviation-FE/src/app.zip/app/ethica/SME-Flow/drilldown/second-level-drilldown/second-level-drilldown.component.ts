import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-second-level-drilldown',
  templateUrl: './second-level-drilldown.component.html',
  styleUrls: ['./second-level-drilldown.component.css']
})
export class SecondLevelDrilldownComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
