import { Component, OnInit, EventEmitter, Output, ViewChild, Input } from '@angular/core';
import { ConstantPool } from '@angular/compiler';
declare var $: any;

@Component({
  selector: 'app-ethica-input',
  templateUrl: './ethica-input.component.html',
  styleUrls: ['./ethica-input.component.css']
})
export class EthicaInputComponent implements OnInit {

 @Input() graphData:number[];
  message:string="hello I am child message"

  @ViewChild("explainability") eSlider;
  @ViewChild("transperancy") tSlider;
  @ViewChild("humanFirst") hSlider;
  @ViewChild("interpretability") iSlider;
  @ViewChild("commonSense") cSlider;
  @ViewChild("auditability") aSlider;

  eValue:number;
  tValue:number;
  hValue:number;
  iValue:number;
  cValue:number;
  aValue:number;

  checkTotal=100;
  scoreTotal=101;
  allTotal=0;

  @Output()  eventEmitter=new EventEmitter<number[]>();

  constructor() { }

  ngOnInit(): void {
    console.log("graphData"+this.graphData);
  this.eValue=this.graphData[0];
  this.tValue=this.graphData[1];
  this.hValue=this.graphData[2];
  this.iValue=this.graphData[3];
  this.cValue=this.graphData[4];
  this.aValue=this.graphData[5];

    $(document).ready(function() {

      const $valueSpan = $('.valueSpan2');
      const $value = $('#customRange11');
      $valueSpan.html($value.val());
      $value.on('input change', () => {
    
        $valueSpan.html($value.val());
      });
    });
  }

  pitch(event: any,i:number) {


    console.log("eSlider.value: "+this.eSlider.value)

    this.allTotal =this.eValue+this.tValue+this.hValue+this.iValue+this.cValue+this.aValue;
    console.log("allTotal:"+this.allTotal);

    if(this.allTotal > this.checkTotal){
      
      if(i == 0){
        
        this.eSlider.value = this.checkTotal-(this.tValue+this.hValue+this.iValue+this.cValue+this.aValue);
        this.graphData[i]=this.eValue=this.eSlider.value
        console.log("this.eSlider.value after change"+this.eSlider.value);
        console.log(this.graphData[i]);
      }
      else if(i ==1){
        this.tSlider.value = this.checkTotal-(this.eValue+this.hValue+this.iValue+this.cValue+this.aValue);
        this.graphData[i]=this.tValue=this.tSlider.value

      }
      else if(i== 2){
        this.hSlider.value = this.checkTotal-(this.eValue+this.tValue+this.iValue+this.cValue+this.aValue);
        this.graphData[i]=this.hValue=this.hSlider.value

      }
      else if( i== 3){
        this.iSlider.value = this.checkTotal-(this.eValue+this.tValue+this.hValue+this.cValue+this.aValue);
        this.graphData[i]=this.iValue=this.iSlider.value

      }
      else if( i==4){
        this.cSlider.value = this.checkTotal-(this.eValue+this.tValue+this.hValue+this.iValue+this.aValue);
        this.graphData[i]=this.cValue=this.cSlider.value

      }
      else{
        this.aSlider.value = this.checkTotal-(this.eValue+this.tValue+this.hValue+this.iValue+this.cValue);
        this.graphData[i]=this.aValue=this.aSlider.value

      }    
    }
    else{
      this.graphData[i]= event.value;
    }

  //   if(this.allTotal < this.checkTotal){
  //     let diff =this.checkTotal-this.allTotal;
  //     let parts= diff/6;
  //     this.graphData[0]=this.eValue=this.eSlider.value + parts
  //     this.graphData[1]=this.tValue=this.tSlider.value + parts
  //     this.graphData[2]=this.hValue=this.hSlider.value + parts
  //     this.graphData[3]=this.eValue=this.iSlider.value + parts
  //     this.graphData[4]=this.tValue=this.cSlider.value + parts
  //     this.graphData[5]=this.hValue=this.aSlider.value + parts

  // }

    this.eventEmitter.emit(this.graphData);


     
    
  }

  save(){
    // console.log("graph data");
    // console.log(this.graphData);
    // this.eventEmitter.emit(this.graphData);
  }

}
