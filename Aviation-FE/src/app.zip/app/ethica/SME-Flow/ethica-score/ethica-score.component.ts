import { Component, OnInit } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { FeedbackCompletedComponent } from '../../USER-Flow/feedback-completed/feedback-completed.component';
import { SimpleDialogComponent } from '../simple-dialog/simple-dialog.component';
import { Router, ActivatedRoute } from '@angular/router';
import { ApiService } from '../../api/api.service';
import { ConditionalExpr } from '@angular/compiler';
import { map } from 'rxjs/operators';
import { Observable } from 'rxjs';

@Component({
  selector: 'app-ethica-score',
  templateUrl: './ethica-score.component.html',
  styleUrls: ['./ethica-score.component.css']
})
export class EthicaScoreComponent implements OnInit {

  // graphData:number[]=[20,20,15,15,15,15];
  scoreDetails=false;
  updated=false;
  // l1:number= 20;
  // l2:number=26
  // l3:number=77;
  // l4:number=95;
  // l5:number=80;
  // l6:number=70;
   l7:number=81;

  // percent:number=70;
   ETHICA_Score2:number=83;

  ETHICA_Score:number;
  E:number;
  T:number;
  H:number;
  I:number;
  C:number;
  A:number;

  Ew:number;
  Tw:number;
  Hw:number;
  Iw:number;
  Cw:number;
  Aw:number;

  EList:string[]=[];
  TList:string[]=[];
  HList:string[]=[];
  IList:string[]=[];
  CList:string[]=[];
  AList:string[]=[];

  EListValues:number[]=[];
  TListValues:number[]=[];
  HListValues:number[]=[];
  IListValues:number[]=[];
  CListValues:number[]=[];
  AListValues:number[]=[];

  barChartDataE=[];
  barChartDataT=[];
  barChartDataH=[];
  barChartDataI=[];
  barChartDataC=[];
  barChartDataA=[];


  scoreDetailsE=false;
  scoreDetailsT=false;
  scoreDetailsH=false;
  scoreDetailsI=false;
  scoreDetailsC=false;
  scoreDetailsA=false;

  


  state$: Observable<object>;


  featuresArray:any[]=[];

  constructor(private _router: Router,private dialog: MatDialog,private  _service:ApiService,public activatedRoute: ActivatedRoute) { }

  ngOnInit(): void {

    this.state$ = this.activatedRoute.paramMap
      .pipe(map(() => window.history.state,
        console.log(window.history.state)
        ))

    this.state$.subscribe(data=>{
      console.log("state data");
      console.log(data);
    })

      
    this._service.scoreData.subscribe((data=>{
      console.log("received score Data");
      console.log(data);


      this.ETHICA_Score=data['ETHICA_Score'];
      this.E=data['E']['Module_Score'];
      this.T=data['T']['Module_Score'];
      this.H=data['H']['Module_Score'];
      this.I=data['I']['Module_Score'];
      this.C=data['C']['Module_Score'];
      this.A=data['A']['Module_Score'];

      this.Ew=data['E']['Weightage'];
      this.Tw=data['T']['Weightage'];
      this.Hw=data['H']['Weightage'];
      this.Iw=data['I']['Weightage'];
      this.Cw=data['C']['Weightage'];
      this.Aw=data['A']['Weightage'];




      for (let key in data){
          if (key == "ETHICA_Score" ){
            continue;
          }
          let wlist:string[]=[];
            let wlistValues:any[]=[];
          for (let i in data[key]["Features"]){
            

            console.log(wlist);
            console.log(wlistValues);
            for (let feature in data[key]["Features"][i]){
              // console.log(data[key]["Features"][i][feature])
              console.log(feature);
              wlist.push(feature);
              //  let ftArray:number[]=[];
              for (let innerfeature in data[key]["Features"][i][feature]){
                // console.log(data[key]["Features"][i][feature][innerfeature]);
                if(innerfeature == 'Score'){
                  let x:number=data[key]["Features"][i][feature][innerfeature];
                // ftArray.push(x)
                console.log(x);
                wlistValues.push(x);
                console.log(wlistValues);
                }
              }
              // this.featuresArray.push(ftArray);
            }
             if( key == "E"){
              this.EList =wlist;
              this.EListValues=wlistValues;
             }else if(key == "T"){
              this.TList =wlist;
              this.TListValues=wlistValues;
             }else if(key == "H"){
              this.HList =wlist;
              this.HListValues=wlistValues;
             }else if(key == "I"){
              this.IList =wlist;
              this.IListValues=wlistValues;              
             }else if(key == "C"){
              this.CList =wlist;
              this.CListValues=wlistValues;              
            }else{
              this.AList =wlist;
              this.AListValues=wlistValues;              
            }
          }
      }
    }
    ))

    for (let index in this.EList){
      let obj={};
      obj={
      
        maxBarThickness: 50,
        minBarLength: 2,
        data: [this.EListValues[index]], label: this.EList[index] };
      this.barChartDataE.push(obj);
    }
    console.log("barChartDataE")
    console.log(this.barChartDataE)

    for (let index in this.TList){
      let obj={};
      obj={
      
        maxBarThickness: 50,
        minBarLength: 2,
        data: [this.TListValues[index]], label: this.TList[index] };
      this.barChartDataT.push(obj);
    }
    console.log("barChartDataT")
    console.log(this.barChartDataT)

    for (let index in this.HList){
      let obj={};
      obj={
      
        maxBarThickness: 50,
        minBarLength: 2,
        data: [this.HListValues[index]], label: this.HList[index] };
      this.barChartDataH.push(obj);
    }
    console.log("barChartDataH")
    console.log(this.barChartDataH)

    for (let index in this.IList){
      let obj={};
      obj={
      
        maxBarThickness: 50,
        minBarLength: 2,
        data: [this.IListValues[index]], label: this.IList[index] };
      this.barChartDataI.push(obj);
    }
    console.log("nikhil is checking")
    console.log(this.IList);
    console.log(this.IListValues)
    console.log("nikhil is done!!!!!!!!!!!!")
    console.log("barChartDataI")
    console.log(this.barChartDataI)

    for (let index in this.CList){
      let obj={};
      obj={
      
        maxBarThickness: 50,
        minBarLength: 2,
        data: [this.CListValues[index]], label: this.CList[index] };
      this.barChartDataC.push(obj);
    }
    console.log("barChartDataC")
    console.log(this.barChartDataC)

    for (let index in this.AList){
      let obj={};
      obj={
      
        maxBarThickness: 50,
        minBarLength: 2,
        data: [this.AListValues[index]], label: this.AList[index] };
      this.barChartDataA.push(obj);
    }
    console.log("barChartDataA")
    console.log(this.barChartDataA)


  }

  openDetails(letter){ 
    switch (letter) {
      case "E": this.scoreDetailsE= true;
                this.scoreDetailsT=false;
                this.scoreDetailsH=false;
                this.scoreDetailsI=false;
                this.scoreDetailsC=false;
                this.scoreDetailsA=false;
                break;
      case "T": this.scoreDetailsE=false;
                this.scoreDetailsT=true;
                this.scoreDetailsH=false;
                this.scoreDetailsI=false;
                this.scoreDetailsC=false;
                this.scoreDetailsA=false;
                break;
      case "H": this.scoreDetailsE=false;
                this.scoreDetailsT=false;
                this.scoreDetailsH=true;
                this.scoreDetailsI=false;
                this.scoreDetailsC=false;
                this.scoreDetailsA=false;
                break;
      case "I": this.scoreDetailsE=false;
                this.scoreDetailsT=false;
                this.scoreDetailsH=false;
                this.scoreDetailsI=true;
                this.scoreDetailsC=false;
                this.scoreDetailsA=false;
                break;
      case "C": this.scoreDetailsE=false;
                this.scoreDetailsT=false;
                this.scoreDetailsH=false;
                this.scoreDetailsI=false;
                this.scoreDetailsC=true;
                this.scoreDetailsA=false;
                break;
      case "A": this.scoreDetailsE=false;
                this.scoreDetailsT=false;
                this.scoreDetailsH=false;
                this.scoreDetailsI=false;
                this.scoreDetailsC=false;
                this.scoreDetailsA=true;
                break;
      default : break;     
    }
  }

  changeScore(){
    this.updated=true;
    this.scoreDetails=false;
  }

  addParameter(){
     this.dialog.open(SimpleDialogComponent);

  }
  defaultLink(){
    this._router.navigate(['/ethica']);
  }


  closeDetails(){
    this.scoreDetailsE=false;
    this.scoreDetailsT=false;
    this.scoreDetailsH=false;
    this.scoreDetailsI=false;
    this.scoreDetailsC=false;
    this.scoreDetailsA=false;
  }

  drilldown(){
    this._router.navigate(["/ethica",{pie:true}],{ state: { graphData:"ETHICA",overallParameters:"subparameters",overallParametersList:"hello"} 
  })
  }

}
