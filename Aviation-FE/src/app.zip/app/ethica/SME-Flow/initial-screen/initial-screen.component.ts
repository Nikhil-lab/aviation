import { Component, OnInit,ViewChild,AfterViewInit, OnChanges } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { MatDialog } from '@angular/material/dialog';
import { EthicaInputComponent } from '../ethica-input/ethica-input.component';
import { NewModelGuidelinesComponent } from '../new-model-guidelines/new-model-guidelines.component';
import { ApiService } from '../../api/api.service';
import { HttpClient } from '@angular/common/http';
import { map } from 'rxjs/operators';
import { Observable } from 'rxjs';
import { SharedService } from 'src/app/_helpers/shared';
import { NgxCsvParser } from 'ngx-csv-parser';
import { NgxCSVParserError } from 'ngx-csv-parser';

@Component({
  selector: 'app-initial-screen',
  templateUrl: './initial-screen.component.html',
  styleUrls: ['./initial-screen.component.css']
})
export class InitialScreenComponent implements OnInit ,OnChanges{
  csvUploaded:boolean=false;
  pie:boolean ;
  disableTrain:boolean=false;
  graphData:number[];
  pieChartLabels: any[] = ['Explanablility','Transparency','Human First','Interpretability','Common Scence','Auditability'];
  optionSelected:string="existingModel";
  clicked:string;
  subParams:boolean=false;
  trainingDataset:boolean=false;
  subParamsList:string[];
  files: File[] = [];
  file_training:File;
  file_validation:File;
  weightages
  isLoading:boolean=false;
  trickyBack:boolean=false;
  csvRecords: any[] = [];
  header = false;

  overallParameters:any;
  overallParametersList={
    // "E":["Disparate_Impact","Overlap","Sufficiency"],
    // "T":["Positive_Predictive_Rate","False_Discovery_Rate","False_Omission_Rate","Negative_Predictive_Value"],
    // "H":["Human_Interaction","Cost_Risk"],
    // "I":["Consistency","Certainty","Accuracy","Dependability","VC_Diemension"],
    // "C":["Junk_Input","Context_Awareness"],
    // "A":["Zero_Value_Neurons","Insignificant_Neurons"],

    "E":["Base_Model_Mean_Difference", "Base_Model_Preference", "RPA_Model_Mean_Difference", "RPA_Model_Preference"],
    "T":["Positive_Predictive_Rate","False_Discovery_Rate","False_Omission_Rate","Negative_Predictive_Value"],
    "H":["Human_Interaction"],
    "I":["Consistency","Certainty","Accuracy","Dependability"],
    "C":["Credit_Score_Custom"],
    "A":[],
  }
  
  formData= new FormData();

  checkTotal=100;
  scoreTotal=101;
  allTotal=0;


  eValue:number;
  tValue:number;
  hValue:number;
  iValue:number;
  cValue:number;
  aValue:number;


  @ViewChild("explainability") eSlider;
  @ViewChild("transperancy") tSlider;
  @ViewChild("humanFirst") hSlider;
  @ViewChild("interpretability") iSlider;
  @ViewChild("commonSense") cSlider;
  @ViewChild("auditability") aSlider;


  @ViewChild("firstParam") firstSlider;
  @ViewChild("secondParam") secondSlider;
  @ViewChild("thirdParam") thirdSlider;
  @ViewChild("fourthParam") fourthSlider;
  @ViewChild("fifthParam") fifthSlider;

  first_param:number;
  second_param:number;
  third_param:number;
  fourth_param:number;
  fifth_param:number;

  predict_Url:string;
  train_file:string="* Choose Training File";
  valid_file:string="* Choose Validation File";
  enableNext:boolean=false;
  state$: Observable<object>;

  @ViewChild('EthicaInputComponent') child;

  constructor( private ngxCsvParser: NgxCsvParser,private route: ActivatedRoute,private http:HttpClient,private router: Router,private dialog: MatDialog,private _service:ApiService,private _sharedService:SharedService) { }
  ngOnChanges(changes: import("@angular/core").SimpleChanges): void {

  }


  ngOnInit(): void {

    // this.state$ = this.route.paramMap
    //   .pipe(map(() => window.history.state,
    //     console.log(window.history.state)
    //     ))

    this.disableTrain=this._sharedService.removeTrainingFile;
    this.pie=false;
    this.route.params.subscribe( params => {
      console.log(params)
      if(params.pie){
        this.pie=params.pie;
      }
      
    
    });
    console.log(history.state);

    if(history.state["graphData"]){
      this.graphData=history.state["graphData"]
    this.eValue=this.graphData[0];
    this.tValue=this.graphData[1];
    this.hValue=this.graphData[2];
    this.iValue=this.graphData[3];
    this.cValue=this.graphData[4];
    this.aValue=this.graphData[5];
    this.overallParameters=history.state['overallParameters']
    this.overallParametersList=history.state['overallParametersList']
    }
    else{
    this.graphData=[20,20,15,15,15,15];
    this.eValue=this.graphData[0];
    this.tValue=this.graphData[1];
    this.hValue=this.graphData[2];
    this.iValue=this.graphData[3];
    this.cValue=this.graphData[4];
    this.aValue=this.graphData[5];

    this.overallParameters={
      "E":[40,20,20,20,0],
      "T":[20,40,20,20,0],
      "H":[50,50,0,0,0],
      "I":[20,20,20,20,20],
      "C":[50,50,0,0,0],
      "A":[50,50,0,0,0]
    };
  }


    // if(history.state){
    //   console.log("router data");
    //   console.log(history.state.data);
    //   this.pie=history.state.data;
   
    // }
    
    


  }

  
 
onSelect(event) {
  console.log(event);
  this.files.push(...event.addedFiles);
  console.log("Files Uploaded");

   this.files.forEach((file,index)=>{
     this.formData.append("Model_File"+[index],file);
   });
  console.log(this.files);
  if(this.files != null) {
    this.enableNext=true;
  }
 
}
 
onRemove(event) {
  console.log(event);
  this.files.splice(this.files.indexOf(event), 1);
}

  // onPicked(event){

  //   const file=(event.target as HTMLInputElement).files[0];
  //   console.log(file);

  //   this.formData.append("file",file);

  //   // this.http.post("http://dummy.restapiexample.com/api/v1/create",{"name":"test","salary":"123","age":"23"}).subscribe((res=>{
  //   //   console.log(res);
  //   // }))

  //   this._service.postData("/uploadModel",this.formData).subscribe(res=>{
  //     console.log(res['message']);

  //                 if(this.optionSelected == "existingModel"){
  //                   this.pie=true; //changes
  //                 }
  //                 else{
  //                   this.router.navigate(["/sme/modelDetails"]);
  //                 }

  //   })

  
  //   // this.pie=true;

  // }

  onPickedTrain(event){
    const file=this.file_training=(event.target as HTMLInputElement).files[0];
    console.log(file);
    this.train_file=file.name;

     this.formData.append("Train_File",file);
  }

  onPickedValid(event){
    const file=this.file_validation=(event.target as HTMLInputElement).files[0];
    console.log(file);
   this.csvUploaded=true;
    this.valid_file=file.name;

     this.formData.append("Validation_File",file);

    
 
    // Parse the file you want to select for the operation along with the configuration
    this.ngxCsvParser.parse(file, { header: this.header, delimiter: ',' })
      .pipe().subscribe((result: Array<any>) => {
 
        console.log('Result of CSV file', result);
        this.csvRecords = result;
      }, (error: NgxCSVParserError) => {
        console.log('Error', error);
      });
    
  }

  back(){
    this.pie=false;
  }

  editWeightage(){
    if(this.optionSelected == "existingModel"){
      this.pie=true;//changes
      this.trickyBack=true;
    }
    else{
      this.router.navigate(["/sme/modelDetails"]);
    }

  }

  backToWeightage(){
    this.pie =true;
    this.trainingDataset=false;
  }
 

  next(){
    this.trainingDataset=true;
    
  }
  

  edit(){
    this.dialog.open(EthicaInputComponent);
  }

  addScreen(){
    this.router.navigate(['/addScreen'])
  }
  editScreen(){
    this.router.navigate(['/editScreen'])
  }

  receiveMessage($event){
    let gData=$event;
    console.log("data received");
    console.log($event);
    for(let i=0;i<gData.length;i++){
        this.graphData[i]=gData[i]
    }
    console.log(this.graphData);

  }


  viewGuidelines(){
    this.dialog.open(NewModelGuidelinesComponent,{
      panelClass: 'myapp-no-padding-dialog',
      height: '450px',
      width: '1200px',

    });
  }


  subParameters(letter){
    letter=letter.toUpperCase();
    console.log("parameters checker"+this.graphData);
    this.eValue=this.graphData[0];
    this.tValue=this.graphData[1];
    this.hValue=this.graphData[2];
    this.iValue=this.graphData[3];
    this.cValue=this.graphData[4];
    this.aValue=this.graphData[5];

    this.clicked=letter.toLowerCase();
    this.subParams=true;

    switch(letter){
      case 'E': this.subParamsList =this.overallParametersList['E'];
                this.first_param=this.overallParameters[letter][0];
                this.second_param=this.overallParameters[letter][1];
                this.third_param=this.overallParameters[letter][2];
                this.fourth_param=this.overallParameters[letter][3];
                this.fifth_param=this.overallParameters[letter][4];
                break;
      case 'T': this.subParamsList =this.overallParametersList['T'];
                this.first_param=this.overallParameters[letter][0];
                this.second_param=this.overallParameters[letter][1];
                this.third_param=this.overallParameters[letter][2];
                this.fourth_param=this.overallParameters[letter][3];
                this.fifth_param=this.overallParameters[letter][4];
                break;
      case 'H':this.subParamsList =this.overallParametersList['H'];
                this.first_param=this.overallParameters[letter][0];
                this.second_param=this.overallParameters[letter][1];
                this.third_param=this.overallParameters[letter][2];
                this.fourth_param=this.overallParameters[letter][3];
                this.fifth_param=this.overallParameters[letter][4];
                break;
      case 'I':this.subParamsList =this.overallParametersList['I'];
                this.first_param=this.overallParameters[letter][0];
                this.second_param=this.overallParameters[letter][1];
                this.third_param=this.overallParameters[letter][2];
                this.fourth_param=this.overallParameters[letter][3];
                this.fifth_param=this.overallParameters[letter][4];
                break;
      case 'C':this.subParamsList =this.overallParametersList['C'];
                this.first_param=this.overallParameters[letter][0];
                this.second_param=this.overallParameters[letter][1];
                this.third_param=this.overallParameters[letter][2];
                this.fourth_param=this.overallParameters[letter][3];
                this.fifth_param=this.overallParameters[letter][4];
                break;
      case 'A':this.subParamsList =this.overallParametersList['A'];
                this.first_param=this.overallParameters[letter][0];
                this.second_param=this.overallParameters[letter][1];
                this.third_param=this.overallParameters[letter][2];
                this.fourth_param=this.overallParameters[letter][3];
                this.fifth_param=this.overallParameters[letter][4];
                break;
    } 

    this.overallParameters[letter]=[this.first_param,this.second_param,this.third_param,this.fourth_param,this.fifth_param]
    console.log("overAllParameters"+this.overallParameters);
    console.log(this.overallParameters);

  }


  pitch(event: any,i:number) {


    // console.log("eSlider.value: "+this.eSlider.value)

    this.allTotal =this.eValue+this.tValue+this.hValue+this.iValue+this.cValue+this.aValue;
    console.log("allTotal:"+this.allTotal);

    if(this.allTotal > this.checkTotal){
      
      if(i == 0){
        
        this.eSlider.value = this.checkTotal-(this.tValue+this.hValue+this.iValue+this.cValue+this.aValue);
        this.graphData[i]=this.eValue=this.eSlider.value
        console.log("this.eSlider.value after change"+this.eSlider.value);
        console.log(this.graphData[i]);
      }
      else if(i ==1){
        this.tSlider.value = this.checkTotal-(this.eValue+this.hValue+this.iValue+this.cValue+this.aValue);
        this.graphData[i]=this.tValue=this.tSlider.value

      }
      else if(i== 2){
        this.hSlider.value = this.checkTotal-(this.eValue+this.tValue+this.iValue+this.cValue+this.aValue);
        this.graphData[i]=this.hValue=this.hSlider.value

      }
      else if( i== 3){
        this.iSlider.value = this.checkTotal-(this.eValue+this.tValue+this.hValue+this.cValue+this.aValue);
        this.graphData[i]=this.iValue=this.iSlider.value

      }
      else if( i==4){
        this.cSlider.value = this.checkTotal-(this.eValue+this.tValue+this.hValue+this.iValue+this.aValue);
        this.graphData[i]=this.cValue=this.cSlider.value

      }
      else{
        this.aSlider.value = this.checkTotal-(this.eValue+this.tValue+this.hValue+this.iValue+this.cValue);
        this.graphData[i]=this.aValue=this.aSlider.value

      }    
    }
    else{
      this.graphData[i]= event.value;
    }
 
    
  }



  subParaValues(i){

    this.overallParameters[this.clicked]=[this.first_param,this.second_param,this.third_param,this.fourth_param,this.fifth_param]
   
    console.log(this.overallParameters);

   

    this.allTotal = this.first_param+this.second_param+this.third_param+this.fourth_param+this.fifth_param;

    if(this.allTotal > this.checkTotal){
      if(i == 0){
        this.firstSlider.value = this.checkTotal-(this.second_param+this.third_param+this.fourth_param+this.fifth_param);
        this.overallParameters[this.clicked][i]=this.first_param=this.firstSlider.value;
      }
      else if(i ==1){
        this.secondSlider.value = this.checkTotal-(this.first_param+this.third_param+this.fourth_param+this.fifth_param);
        this.overallParameters[this.clicked][i]=this.second_param=this.secondSlider.value;
      }
      else if(i ==2 ){
        this.thirdSlider.value = this.checkTotal-(this.first_param+this.second_param+this.fourth_param+this.fifth_param);
        this.overallParameters[this.clicked][i]=this.third_param=this.thirdSlider.value;
      }
      else if(i == 3 ){
        this.fourthSlider.value = this.checkTotal-(this.first_param+this.second_param+this.third_param+this.fifth_param);
        this.overallParameters[this.clicked][i]=this.fourth_param=this.fourthSlider.value;
      }
      else{
        this.fifthSlider.value = this.checkTotal-(this.first_param+this.second_param+this.third_param+this.fourth_param);
        this.overallParameters[this.clicked][i]=this.fifth_param=this.fifthSlider.value;
      }

    }else{
      this.overallParameters[this.clicked]=[this.first_param,this.second_param,this.third_param,this.fourth_param,this.fifth_param]
      console.log(this.overallParameters);
    }
  }


  goToScore(){
    let frontendData={
    // "Train_File": this.file_training,
    // "Validation_File": this.file_validation,
    // "Model_File": this.files,
    "Predict_URL": this.predict_Url,


    "E": {
        "Weightage": this.graphData[0],
        "Features": [{
                "Disparate_Impact": {
                    "Weightage": this.overallParameters['E'][0]
                }
            }, {
                "Overlap": {
                    "Weightage": this.overallParameters['E'][1]
                }
            }, {
                "Sufficiency": {
                    "Weightage": this.overallParameters['E'][2]
                }
            }
        ]
    },
    "T": {
        "Weightage": this.graphData[1],
        "Features": [{
                "Positive_Predictive_Rate": {
                    "Weightage": this.overallParameters['T'][0]
                }
            }, {
              "False_Discovery_Rate": {
                  "Weightage": this.overallParameters['T'][1]
              }
          },{
            "False_Omission_Rate": {
                "Weightage": this.overallParameters['T'][2]
            }
        },{
                "Negative_Predictive_Value": {
                    "Weightage": this.overallParameters['T'][3]
                }
            }
        ]
    },
    "H": {
        "Weightage": this.graphData[2],
        "Features": [{
                "Human_Interaction": {
                    "Weightage": this.overallParameters['H'][0]
                }
            }, {
                "Cost_Risk": {
                    "Weightage": this.overallParameters['H'][1]
                }
            }
        ]
    },

    "I": {
      "Weightage": this.graphData[3],
      "Features": [{
              "Consistency": {
                  "Weightage": this.overallParameters['I'][0]
              }
          }, {
              "Certainty": {
                  "Weightage": this.overallParameters['I'][1]
              }
          },{
            "Accuracy": {
                "Weightage": this.overallParameters['I'][2]
            }
        },{
          "Dependability": {
              "Weightage": this.overallParameters['I'][3]
          }
      }, {
              "VC_Diemension": {
                  "Weightage": this.overallParameters['I'][4]
              }
          }
      ]
  },

  "C": {
    "Weightage": this.graphData[4],
    "Features": [{
            "Junk_Input": {
                "Weightage": this.overallParameters['C'][0]
            }
        }, {
            "Context_Awareness": {
                "Weightage": this.overallParameters['C'][1]
            }
        }
    ]
},
"A": {
  "Weightage": this.graphData[5],
  "Features": [{
          "Zero_Value_Neurons": {
              "Weightage": this.overallParameters['A'][0]
          }
      }, {
          "Insignificant_Neurons": {
              "Weightage": this.overallParameters['A'][1]
          }
      }
  ]
}

    };
    console.log("DATA READY TO SEND")
    console.log(frontendData);

    // var myJSON = JSON.stringify(frontendData);
    // this.formData.append("JsonString",myJSON);

    for ( var key in frontendData ) {
    
      this.formData.append(key,JSON.stringify(frontendData[key]));
    }
    
     
  
    
    this.isLoading= true;

    this._service.postData("/getScores",this.formData).subscribe(scoreData =>{
      // setTimeout(() => {
      //  this.isLoading=false;},3000);
      this.isLoading=false;
      console.log(scoreData);
      this._service.setScoreData(scoreData);
      this.router.navigate(['/score']);
    })

// for (let letter in this.overallParameters){
//    let weightages={}
//     letter: {
//       Weightage: this.graphData[0];
//       for( let subparam in this,this.overallParametersList){
//          Features: [{
//           subparam: {
//               "Weightage": this.overallParameters[letter][0]
//           }
//       }   
//   ]
//       }
//   }
// }
     
   
  }

  gotoDashboard(){
    this.router.navigate(['/ethica']);
    this._sharedService.setTrain();
  }

}
