import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { EthicaCoreComponent } from './ethica-core.component';

describe('EthicaCoreComponent', () => {
  let component: EthicaCoreComponent;
  let fixture: ComponentFixture<EthicaCoreComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ EthicaCoreComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(EthicaCoreComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
