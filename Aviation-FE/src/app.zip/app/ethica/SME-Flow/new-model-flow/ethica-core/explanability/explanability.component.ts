import { Component, OnInit, EventEmitter, Output } from "@angular/core";
import { PageEvent } from "@angular/material/paginator";


@Component({
  selector: "app-explanability",
  templateUrl: "./explanability.component.html",
  styleUrls: ["./explanability.component.css"],
})
export class ExplanabilityComponent implements OnInit {
  totalPages = 2;
  pageSizeOptions = [1, 2, 5, 10];
  postsPerPage: number = 1;
  surveyForm = [
    {
      query:
        "Is the data model designed such that the prediction is reasonably correct?",
    },
    {
      query:
        "Are the personnel involved in Data Curation aware how the application works so that they can prepare data such that each description is sufficiently detailed and all scenarios are covered?",
    },
    {
      query:
        "Do the Designers, Developers, Testers have enough domain knowledge & aware of the terminologies used?",
    },
    {
      query:
        "Are the Designers, Developers, Testers aware of the Target audience, AS-IS & TO-BE processes / scenarios?",
    },
    { query: "Is the Tester aware of the underlying algorithms?" },
    {
      query:
        "Is there enough documentation for all personas to understand how the application works?",
    },
    {
      query: "Is the document jargon-free / has acronyms & glossary sections?",
    },
    {
      query:
        "Does the Tester have enough domain knowledge, aware of the terminologies used?  ",
    },
    {
      query:
        "Are the strengths & known weaknesses / limitations & road map to address the limitations documented & published?",
    },
    { query: "Is the documentation reviewed & approved by SMEs?" },
    {
      query:
        "Are any references available on the usefulness & advantages of using the application?",
    },
    {
      query:
        "Is feedback collected from users and incorporated into the user guide?",
    },
  ];

  pageIndex: number = 1;
  ratings: any;
  @Output() pageEmitter = new EventEmitter();

  constructor() {}

  ngOnInit(): void {
    
  }

  onChangePage(pageData: PageEvent) {
    console.log(pageData);
    this.pageIndex = pageData["pageIndex"];
    if (pageData.length == pageData.pageIndex + 1) {
      this.pageEmitter.emit("completed");
    }
  }
}
