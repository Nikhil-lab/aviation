import { Component, OnInit } from "@angular/core";
declare var $: any;

@Component({
  selector: "app-survey-form",
  templateUrl: "./survey-form.component.html",
  styleUrls: ["./survey-form.component.css"],
})
export class SurveyFormComponent implements OnInit {
  selectedItem:string;

  surveyForm = [
    {
      query:
        "Is the data model designed such that the prediction is reasonably correct?",
    },
    {
      query:
        "Are the personnel involved in Data Curation aware how the application works so that they can prepare data such that each description is sufficiently detailed and all scenarios are covered?",
    },
    {
      query:
        "Do the Designers, Developers, Testers have enough domain knowledge & aware of the terminologies used?",
    },
    {
      query:
        "Are the Designers, Developers, Testers aware of the Target audience, AS-IS & TO-BE processes / scenarios?",
    },
    { query: "Is the Tester aware of the underlying algorithms?" },
    {
      query:
        "Is there enough documentation for all personas to understand how the application works?",
    },
    {
      query: "Is the document jargon-free / has acronyms & glossary sections?",
    },
    {
      query:
        "Does the Tester have enough domain knowledge, aware of the terminologies used?  ",
    },
    {
      query:
        "Are the strengths & known weaknesses / limitations & road map to address the limitations documented & published?",
    },
    { query: "Is the documentation reviewed & approved by SMEs?" },
    {
      query:
        "Are any references available on the usefulness & advantages of using the application?",
    },
    {
      query:
        "Is feedback collected from users and incorporated into the user guide?",
    },
  ];
  
  constructor() {}

  ngOnInit(): void {
    var survey = []; //Bidimensional array: [ [1,3], [2,4] ]

    //Switcher function:
    $(document).ready(function() {
    $(".rb-tab").click(function () {
      //Spot switcher:
      $(this).parent().find(".rb-tab").removeClass("rb-tab-active");
      $(this).addClass("rb-tab-active");
    });

    //Save data:
    $(".trigger").click(function () {
      //Empty array:
      survey = [];
      //Push data:
      for (let i = 1; i <= $(".rb").length; i++) {
        var rb = "rb" + i;
        var rbValue = parseInt(
          $("#rb-" + i)
            .find(".rb-tab-active")
            .attr("data-value")
        );
        //Bidimensional array push:
        survey.push([i, rbValue]); //Bidimensional array: [ [1,3], [2,4] ]
      }
      //Debug:
      debug();
    });

    //Debug:
    function debug() {
      var debug = "";
      for (let i = 0; i < survey.length; i++) {
        debug += "Nº " + survey[i][0] + " = " + survey[i][1] + "\n";
      }
      alert(debug);
    }

  });

  
  }

  clickedOption(event){
    console.log(event);
  }

  listClick(event, newValue) {
    console.log(newValue);
    this.selectedItem = newValue;  // don't forget to update the model here
    // ... do other stuff here ...
}


}
