import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-new-model-guidelines',
  templateUrl: './new-model-guidelines.component.html',
  styleUrls: ['./new-model-guidelines.component.css']
})
export class NewModelGuidelinesComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
