import { Component, OnInit } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { FeedbackComponent } from './feedback/feedback.component';
import { ApiService } from '../api/api.service';
import {MatSnackBar} from '@angular/material/snack-bar';
import { SnackBarComponent } from '../snack-bar/snack-bar.component';
import { AuthService } from '../../auth/auth.service';
import { ActivatedRoute } from '@angular/router';
import { SharedService } from 'src/app/_helpers/shared';


@Component({
  selector: 'app-appraisal',
  templateUrl: './appraisal.component.html',
  styleUrls: ['./appraisal.component.css']
})
export class AppraisalComponent implements OnInit {

  // comments: string = "<p><b>Note: Your input is anonymous, it will not be revealed or used</b></p><p>Please input your overall appraisal comments here.</p>";
  comments: string;
  reviewDialog: boolean = false;
  formdata = new FormData();
  enable:boolean=false;
  disableSubmit:boolean=true;
  isLoading:boolean=false;
  reviewData:any;
  constructor(private service: ApiService,private _snackBar: MatSnackBar, public dialog: MatDialog,private authService: AuthService, private route: ActivatedRoute, private _shared: SharedService) { 
    
  }

  ngOnInit(): void {
     let x =this._shared.getBaseUrl();
     console.log(x);
  }


  handleEvent(event) {

    // console.log(event);
    console.log(this.comments);
  }

  reviewComments() {
    // this.reviewDialog = true;
    this.disableSubmit=false;
    this.enable=true;
    this.isLoading=true;
    this.service.setUserComments(this.comments);   //setting user comments
    let toBackend={
      "description": this.comments,
      "emp_id": "",
      "mgr_id": "",
      "service_type": "EMP",
      "Text_display": "Y"
  }
    this.service.postData("/reviewComments",toBackend).subscribe(data =>{
      this.isLoading=false;
      this.reviewDialog = true;
      this.reviewData=data;
      console.log("got reveiew comments");
      console.log(this.reviewData);
      // setTimeout(() => {
      // this.enable=false;},3000);
       this.enable=false;
    })
  }

  getFeedback() {

    const dialogRef = this.dialog.open(FeedbackComponent, {
      panelClass: 'myapp-no-padding-dialog',
      height: '450px',
      width: '1200px',

    });

    

  }

  save() {
    console.log("tryin to save");
    this.formdata.append("comments", this.comments);

    let userComments={"comment":this.comments}
    this.isLoading=true;
    this.service.postData('/userComments',userComments).subscribe(data => {
      this.isLoading=false;
      console.log("successfully saved");
      console.log(data['message']);
      
      // this._snackBar.open("Comments Saved Successfully",'',{duration:2000} );
    //   this.snackBar.open(message.text, action, {
    //     duration: this.timeOut,
    //     verticalPosition: 'bottom', // 'top' | 'bottom'
    //     horizontalPosition: 'end', //'start' | 'center' | 'end' | 'left' | 'right'
    //     panelClass: ['red-snackbar'],
    // });
      this._snackBar.openFromComponent(SnackBarComponent, {
        duration: 2000,
         data:"Comments Saved Successfully",
        verticalPosition: 'top',
        horizontalPosition : 'end'

      });
    });

    // this.service.getdata().subscribe(data =>{
    //   console.log(data);
    // })
    
  }






}