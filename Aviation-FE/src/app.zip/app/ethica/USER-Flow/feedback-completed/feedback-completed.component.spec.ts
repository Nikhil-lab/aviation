import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { FeedbackCompletedComponent } from './feedback-completed.component';

describe('FeedbackCompletedComponent', () => {
  let component: FeedbackCompletedComponent;
  let fixture: ComponentFixture<FeedbackCompletedComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ FeedbackCompletedComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(FeedbackCompletedComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
