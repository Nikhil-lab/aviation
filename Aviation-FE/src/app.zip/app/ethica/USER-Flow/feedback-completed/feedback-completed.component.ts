import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { ApiService } from '../../api/api.service';

@Component({
  selector: 'app-feedback-completed',
  templateUrl: './feedback-completed.component.html',
  styleUrls: ['./feedback-completed.component.css']
})
export class FeedbackCompletedComponent implements OnInit {

  constructor(private service:ApiService,private router: Router) { }

  ngOnInit(): void {
  }

  redirect(){
    console.log("redirect called")
    this.router.navigate(['/submit']);
   

  }

}
