import { Component, OnInit } from '@angular/core';
import {MatDialog} from '@angular/material/dialog';
import { FeedbackCompletedComponent } from '../feedback-completed/feedback-completed.component';
import { Router } from '@angular/router';

declare var $: any;



@Component({
  selector: 'app-feedback',
  templateUrl: './feedback.component.html',
  styleUrls: ['./feedback.component.css']
})
export class FeedbackComponent implements OnInit {

  feedbackComments:string;
  ratings:any;

   

  constructor(private router: Router,public dialog: MatDialog) { }

  ngOnInit(): void {

    let survey = []; //Bidimensional array: [ [1,3], [2,4] ]

    //Switcher function:
$(".rb-tab").click(function(){
  //Spot switcher:
  
  $(this).parent().find(".rb-tab").removeClass("rb-tab-active");
  $(this).addClass("rb-tab-active");
});



//Save data:
$(".trigger").click(()=>{
  //Empty array:
  survey = [];
  //Push data:
  for (let i=1; i<=$(".rb").length; i++) {
    var rb = "rb" + i;
    var rbValue = parseInt($("#rb-"+i).find(".rb-tab-active").attr("data-value"));
    //Bidimensional array push:
    survey.push([i, rbValue]); //Bidimensional array: [ [1,3], [2,4] ]
  };
  //Debug:
  //check();
  this.ratings=survey;
 
});

//Debug:
// function check(){
//   console.log(survey);
//   var debug = "";
//   for (let i=0; i<survey.length; i++) {
//     debug += "Nº " + survey[i][0] + " = " + survey[i][1] + "\n";
//   };
//   alert(debug);
// };

  }

  feedbackComplete(){
    const dialogRef = this.dialog.open(FeedbackCompletedComponent,{panelClass: 'myapp-no-padding-dialog',
      height: '530px',
      width: '730px',
      
    });

    console.log("Feedback data fore backend");
    console.log(this.feedbackComments);
    console.log(this.ratings);

  }

  nofeedback(){

    this.router.navigate(['/submit']);

    console.log("No feedback given by customer");

  }

  

 
  



}
