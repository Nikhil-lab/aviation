import { Component, OnInit, OnDestroy } from '@angular/core';
import { ApiService } from '../../api/api.service';
import { Subscription } from 'rxjs';
import { Router } from '@angular/router';

@Component({
  selector: 'app-final',
  templateUrl: './final.component.html',
  styleUrls: ['./final.component.css']
})
export class FinalComponent implements OnInit {

  data: any ;
  reviewData:any;
  private userCommentsListenerSubs: Subscription;

  constructor(private _router:Router,private service: ApiService) { }


  ngOnInit(): void {

    this.service.sharedMessage.subscribe(result =>{
      console.log(result);
      this.data =result;


      //////
      let toBackend={
        "description": this.data,
        "emp_id": "",
        "mgr_id": "",
        "service_type": "EMP",
        "Text_display": "Y"
    }
      this.service.postData("/reviewComments",toBackend).subscribe(result =>{

        this.reviewData=result;

      });



      /////


      if(this.data){

        document.getElementById('result').innerHTML = this.data;
      }
       
    })
    
    // this.service.getdata('/backendData').subscribe((data => {
    // this.service.getdata('/userComments').subscribe((data => {

    //   console.log(data);

    //   this.data = data["comment"];
    //   this.callme();
    // }))


  }


  defaultLink(){
    this._router.navigate(['/appraisal']);
  }

 

}
