import { Component, OnInit, Input, OnChanges } from '@angular/core';
import { ApiService } from '../../api/api.service';


@Component({
  selector: 'app-review-comments',
  templateUrl: './review-comments.component.html',
  styleUrls: ['./review-comments.component.css']
})
export class ReviewCommentsComponent implements OnInit ,OnChanges{

  @Input() comments:any;
  
  test:any;
  success1:boolean;
  success2:boolean;
  success3:boolean;

  success:boolean=true;

  constructor(private service:ApiService) { }

  ngOnChanges(changes: import("@angular/core").SimpleChanges): void {
    console.log("NGONCHANGES")
    if (this.comments){
      this.success1=JSON.parse(this.comments.result[0]['Sentiment']);
    this.success2=JSON.parse(this.comments.result[1]['Sentiment']);
    this.success3=JSON.parse(this.comments.result[2]['Sentiment']);

    } 
  }

  ngOnInit(): void {
    console.log("NGONINIT")
    
  }
  

}
