import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import {environment} from "../../../environments/environment"
import { ConfigService } from 'src/app/config.service';
import { SharedService } from 'src/app/_helpers/shared';
import { BehaviorSubject, Subject } from 'rxjs';

// let BACKEND_URl=environment.apiUrl;


@Injectable({
  providedIn: 'root'
})
export class ApiService {
  
  base:string;
  private userCommentStatusListner =new BehaviorSubject<string>("not Loaded");
  private scoreDataListner =new BehaviorSubject<{}>({});

  sharedMessage=this.userCommentStatusListner.asObservable();
  scoreData=this.scoreDataListner.asObservable();

  constructor(private http: HttpClient,private config: ConfigService, private _shared: SharedService) {

   }


  getdata(endPoint){

   let base= localStorage.getItem("baseURL");
   console.log(base);
  return this.http.get(base+endPoint);
  }


  postData(endPoint,data){
     let base= localStorage.getItem("baseURL");
   return this.http.post( base+endPoint,data);
  }

  deleteData(endPoint,id){
    return this.http.delete("http://localhost:3000/userComments/"+id);
  }

  // getUserComments(){
  //   return this.userCommentStatusListner.asObservable();
  // }

  setUserComments(value){
    console.log("setting Data"+ value);
    this.userCommentStatusListner.next(value);
  }

  setScoreData(value){
    this.scoreDataListner.next(value);
  }

  
}
