export interface UserComment{
    id:string;
    comment:string;
    creator:string;
}