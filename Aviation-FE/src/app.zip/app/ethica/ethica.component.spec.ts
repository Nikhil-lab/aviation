import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { EthicaComponent } from './ethica.component';

describe('EthicaComponent', () => {
  let component: EthicaComponent;
  let fixture: ComponentFixture<EthicaComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ EthicaComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(EthicaComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
