import { Component, OnInit, DoCheck } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { ApiService } from './api/api.service';
import { AuthService } from '../auth/auth.service';
import { Router } from '@angular/router';
import { SharedService } from '../_helpers/shared';

@Component({
  selector: 'app-ethica',
  templateUrl: './ethica.component.html',
  styleUrls: ['./ethica.component.css']
})
export class EthicaComponent implements OnInit ,DoCheck {
  viewTable=false;
  tableData:any[];
  type:string;
  displayedColumns:string[];
  displayedColumnsUsers: string[] = ['user_id', 'user_name', 'group_id', 'role'];
  displayedColumnsProjects:string[]=['project_id', 'project_name','created_by','group_id'];

  cardsData=[20,20,10,25,25]
  cardsLabels=['Users','Applications','Models','Tickets','Projects'];

  // cards=[
  //   {"Users":"1,24,293"},
  //   {"Projects":"18,000"},
  //   {"Applications":"2,34,675"},
  //   {"Models":"4,78,989"},
  //   {"Tickets":"11,34,234"}
  // ]
  cards=[];
  userData=[];
  projectData=[];
  userId:string;
   
   cardTitles: string[]=[]
    cardTitleValues:string[]=[]

    pieLables:string[]=[];
    pieValues:number[]=[];

  // userData=[
  //   {
  //     "id": "1",
  //     "name": "Nikhil",
  //     "progress": "69",
  //     "color": "fuchsia"
  //   },
  //   {
  //     "id": "2",
  //     "name": "Nikshep",
  //     "progress": "96",
  //     "color": "teal"
  //   },
  //   {
  //     "id": "3",
  //     "name": "Jaka",
  //     "progress": "33",
  //     "color": "teal"
  //   },
  //   {
  //     "id": "4",
  //     "name": "Arun",
  //     "progress": "29",
  //     "color": "navy"
  //   },
  //   {
  //     "id": "5",
  //     "name": "Jack T.",
  //     "progress": "58",
  //     "color": "black"
  //   },
  //   {
  //     "id": "6",
  //     "name": "Oliver A.",
  //     "progress": "60",
  //     "color": "black"
  //   },
  //   {
  //     "id": "7",
  //     "name": "Olivia A.",
  //     "progress": "42",
  //     "color": "teal"
  //   },
  //   {
  //     "id": "8",
  //     "name": "Charlotte E.",
  //     "progress": "18",
  //     "color": "green"
  //   },
  //   {
  //     "id": "9",
  //     "name": "Atticus M.",
  //     "progress": "24",
  //     "color": "green"
  //   },
  //   {
  //     "id": "10",
  //     "name": "Jasper M.",
  //     "progress": "92",
  //     "color": "blue"
  //   },
  //   {
  //     "id": "11",
  //     "name": "Mia C.",
  //     "progress": "46",
  //     "color": "orange"
  //   },
  //   {
  //     "id": "12",
  //     "name": "Atticus J.",
  //     "progress": "99",
  //     "color": "red"
  //   },
  //   {
  //     "id": "13",
  //     "name": "Charlotte M.",
  //     "progress": "55",
  //     "color": "red"
  //   },
  //   {
  //     "id": "14",
  //     "name": "Amelia O.",
  //     "progress": "99",
  //     "color": "green"
  //   },
  //   {
  //     "id": "15",
  //     "name": "Thomas J.",
  //     "progress": "36",
  //     "color": "purple"
  //   },
  //   {
  //     "id": "16",
  //     "name": "Arthur O.",
  //     "progress": "82",
  //     "color": "yellow"
  //   },
  //   {
  //     "id": "17",
  //     "name": "Charlotte C.",
  //     "progress": "96",
  //     "color": "olive"
  //   },
  //   {
  //     "id": "18",
  //     "name": "Theodore J.",
  //     "progress": "93",
  //     "color": "teal"
  //   },
  //   {
  //     "id": "19",
  //     "name": "Maia A.",
  //     "progress": "80",
  //     "color": "aqua"
  //   },
  //   {
  //     "id": "20",
  //     "name": "Isla A.",
  //     "progress": "44",
  //     "color": "olive"
  //   },
  //   {
  //     "id": "21",
  //     "name": "Atticus T.",
  //     "progress": "90",
  //     "color": "olive"
  //   },
  //   {
  //     "id": "22",
  //     "name": "Mia O.",
  //     "progress": "69",
  //     "color": "navy"
  //   },
  //   {
  //     "id": "23",
  //     "name": "Maia E.",
  //     "progress": "67",
  //     "color": "orange"
  //   },
  //   {
  //     "id": "24",
  //     "name": "Levi V.",
  //     "progress": "69",
  //     "color": "teal"
  //   },
  //   {
  //     "id": "25",
  //     "name": "Mia C.",
  //     "progress": "61",
  //     "color": "orange"
  //   },
  //   {
  //     "id": "26",
  //     "name": "Isla C.",
  //     "progress": "22",
  //     "color": "yellow"
  //   },
  //   {
  //     "id": "27",
  //     "name": "Elizabeth O.",
  //     "progress": "88",
  //     "color": "maroon"
  //   },
  //   {
  //     "id": "28",
  //     "name": "Thomas O.",
  //     "progress": "90",
  //     "color": "aqua"
  //   },
  //   {
  //     "id": "29",
  //     "name": "Olivia M.",
  //     "progress": "49",
  //     "color": "yellow"
  //   },
  //   {
  //     "id": "30",
  //     "name": "Maia A.",
  //     "progress": "74",
  //     "color": "black"
  //   },
  //   {
  //     "id": "31",
  //     "name": "Jasper L.",
  //     "progress": "18",
  //     "color": "black"
  //   },
  //   {
  //     "id": "32",
  //     "name": "Olivia I.",
  //     "progress": "79",
  //     "color": "fuchsia"
  //   },
  //   {
  //     "id": "33",
  //     "name": "Levi O.",
  //     "progress": "37",
  //     "color": "teal"
  //   },
  //   {
  //     "id": "34",
  //     "name": "Oliver C.",
  //     "progress": "98",
  //     "color": "purple"
  //   },
  //   {
  //     "id": "35",
  //     "name": "Oliver C.",
  //     "progress": "30",
  //     "color": "fuchsia"
  //   },
  //   {
  //     "id": "36",
  //     "name": "Levi V.",
  //     "progress": "29",
  //     "color": "fuchsia"
  //   },
  //   {
  //     "id": "37",
  //     "name": "Jasper E.",
  //     "progress": "57",
  //     "color": "blue"
  //   },
  //   {
  //     "id": "38",
  //     "name": "Cora A.",
  //     "progress": "58",
  //     "color": "olive"
  //   },
  //   {
  //     "id": "39",
  //     "name": "Jasper C.",
  //     "progress": "26",
  //     "color": "green"
  //   },
  //   {
  //     "id": "40",
  //     "name": "Thomas M.",
  //     "progress": "9",
  //     "color": "purple"
  //   },
  //   {
  //     "id": "41",
  //     "name": "Amelia A.",
  //     "progress": "76",
  //     "color": "teal"
  //   },
  //   {
  //     "id": "42",
  //     "name": "Jasper T.",
  //     "progress": "54",
  //     "color": "orange"
  //   },
  //   {
  //     "id": "43",
  //     "name": "Olivia I.",
  //     "progress": "89",
  //     "color": "aqua"
  //   },
  //   {
  //     "id": "44",
  //     "name": "Arthur I.",
  //     "progress": "95",
  //     "color": "purple"
  //   },
  //   {
  //     "id": "45",
  //     "name": "Arthur C.",
  //     "progress": "76",
  //     "color": "red"
  //   },
  //   {
  //     "id": "46",
  //     "name": "Amelia A.",
  //     "progress": "14",
  //     "color": "olive"
  //   },
  //   {
  //     "id": "47",
  //     "name": "Thomas A.",
  //     "progress": "25",
  //     "color": "yellow"
  //   },
  //   {
  //     "id": "48",
  //     "name": "Jasper I.",
  //     "progress": "21",
  //     "color": "purple"
  //   },
  //   {
  //     "id": "49",
  //     "name": "Violet M.",
  //     "progress": "82",
  //     "color": "aqua"
  //   },
  //   {
  //     "id": "50",
  //     "name": "Isla L.",
  //     "progress": "84",
  //     "color": "green"
  //   },
  //   {
  //     "id": "51",
  //     "name": "Levi M.",
  //     "progress": "49",
  //     "color": "orange"
  //   },
  //   {
  //     "id": "52",
  //     "name": "Isabella A.",
  //     "progress": "43",
  //     "color": "red"
  //   },
  //   {
  //     "id": "53",
  //     "name": "Theodore L.",
  //     "progress": "12",
  //     "color": "olive"
  //   },
  //   {
  //     "id": "54",
  //     "name": "Amelia T.",
  //     "progress": "32",
  //     "color": "teal"
  //   },
  //   {
  //     "id": "55",
  //     "name": "Asher C.",
  //     "progress": "35",
  //     "color": "red"
  //   },
  //   {
  //     "id": "56",
  //     "name": "Isla T.",
  //     "progress": "78",
  //     "color": "teal"
  //   },
  //   {
  //     "id": "57",
  //     "name": "Theodore V.",
  //     "progress": "80",
  //     "color": "teal"
  //   },
  //   {
  //     "id": "58",
  //     "name": "Atticus I.",
  //     "progress": "69",
  //     "color": "blue"
  //   },
  //   {
  //     "id": "59",
  //     "name": "Isla A.",
  //     "progress": "25",
  //     "color": "aqua"
  //   },
  //   {
  //     "id": "60",
  //     "name": "Jack M.",
  //     "progress": "16",
  //     "color": "gray"
  //   },
  //   {
  //     "id": "61",
  //     "name": "Charlotte T.",
  //     "progress": "54",
  //     "color": "olive"
  //   },
  //   {
  //     "id": "62",
  //     "name": "Arthur A.",
  //     "progress": "6",
  //     "color": "green"
  //   },
  //   {
  //     "id": "63",
  //     "name": "Violet A.",
  //     "progress": "7",
  //     "color": "lime"
  //   },
  //   {
  //     "id": "64",
  //     "name": "Oliver M.",
  //     "progress": "56",
  //     "color": "aqua"
  //   },
  //   {
  //     "id": "65",
  //     "name": "Mia V.",
  //     "progress": "16",
  //     "color": "fuchsia"
  //   },
  //   {
  //     "id": "66",
  //     "name": "Isla L.",
  //     "progress": "54",
  //     "color": "blue"
  //   },
  //   {
  //     "id": "67",
  //     "name": "Cora T.",
  //     "progress": "81",
  //     "color": "olive"
  //   },
  //   {
  //     "id": "68",
  //     "name": "Amelia O.",
  //     "progress": "60",
  //     "color": "yellow"
  //   },
  //   {
  //     "id": "69",
  //     "name": "Asher A.",
  //     "progress": "75",
  //     "color": "aqua"
  //   },
  //   {
  //     "id": "70",
  //     "name": "Asher M.",
  //     "progress": "58",
  //     "color": "red"
  //   },
  //   {
  //     "id": "71",
  //     "name": "Arthur C.",
  //     "progress": "67",
  //     "color": "purple"
  //   },
  //   {
  //     "id": "72",
  //     "name": "Isabella O.",
  //     "progress": "24",
  //     "color": "fuchsia"
  //   },
  //   {
  //     "id": "73",
  //     "name": "Isla M.",
  //     "progress": "89",
  //     "color": "red"
  //   },
  //   {
  //     "id": "74",
  //     "name": "Isla V.",
  //     "progress": "15",
  //     "color": "orange"
  //   },
  //   {
  //     "id": "75",
  //     "name": "Mia E.",
  //     "progress": "46",
  //     "color": "lime"
  //   },
  //   {
  //     "id": "76",
  //     "name": "Oliver A.",
  //     "progress": "23",
  //     "color": "orange"
  //   },
  //   {
  //     "id": "77",
  //     "name": "Arthur M.",
  //     "progress": "39",
  //     "color": "lime"
  //   },
  //   {
  //     "id": "78",
  //     "name": "Arthur M.",
  //     "progress": "62",
  //     "color": "lime"
  //   },
  //   {
  //     "id": "79",
  //     "name": "Jack A.",
  //     "progress": "70",
  //     "color": "navy"
  //   },
  //   {
  //     "id": "80",
  //     "name": "Levi V.",
  //     "progress": "10",
  //     "color": "lime"
  //   },
  //   {
  //     "id": "81",
  //     "name": "Mia E.",
  //     "progress": "26",
  //     "color": "yellow"
  //   },
  //   {
  //     "id": "82",
  //     "name": "Thomas L.",
  //     "progress": "38",
  //     "color": "aqua"
  //   },
  //   {
  //     "id": "83",
  //     "name": "Cora M.",
  //     "progress": "0",
  //     "color": "fuchsia"
  //   },
  //   {
  //     "id": "84",
  //     "name": "Theodore L.",
  //     "progress": "98",
  //     "color": "aqua"
  //   },
  //   {
  //     "id": "85",
  //     "name": "Theodore A.",
  //     "progress": "25",
  //     "color": "blue"
  //   },
  //   {
  //     "id": "86",
  //     "name": "Violet T.",
  //     "progress": "96",
  //     "color": "yellow"
  //   },
  //   {
  //     "id": "87",
  //     "name": "Theodore A.",
  //     "progress": "16",
  //     "color": "navy"
  //   },
  //   {
  //     "id": "88",
  //     "name": "Thomas C.",
  //     "progress": "82",
  //     "color": "gray"
  //   },
  //   {
  //     "id": "89",
  //     "name": "Theodore T.",
  //     "progress": "94",
  //     "color": "black"
  //   },
  //   {
  //     "id": "90",
  //     "name": "Thomas A.",
  //     "progress": "80",
  //     "color": "black"
  //   },
  //   {
  //     "id": "91",
  //     "name": "Asher T.",
  //     "progress": "96",
  //     "color": "lime"
  //   },
  //   {
  //     "id": "92",
  //     "name": "Charlotte C.",
  //     "progress": "16",
  //     "color": "orange"
  //   },
  //   {
  //     "id": "93",
  //     "name": "Charlotte A.",
  //     "progress": "93",
  //     "color": "aqua"
  //   },
  //   {
  //     "id": "94",
  //     "name": "Isla J.",
  //     "progress": "78",
  //     "color": "lime"
  //   },
  //   {
  //     "id": "95",
  //     "name": "Jasper A.",
  //     "progress": "34",
  //     "color": "lime"
  //   },
  //   {
  //     "id": "96",
  //     "name": "Thomas A.",
  //     "progress": "17",
  //     "color": "blue"
  //   },
  //   {
  //     "id": "97",
  //     "name": "Olivia O.",
  //     "progress": "29",
  //     "color": "teal"
  //   },
  //   {
  //     "id": "98",
  //     "name": "Olivia T.",
  //     "progress": "45",
  //     "color": "blue"
  //   },
  //   {
  //     "id": "99",
  //     "name": "Isabella A.",
  //     "progress": "40",
  //     "color": "maroon"
  //   },
  //   {
  //     "id": "100",
  //     "name": "Oliver A.",
  //     "progress": "95",
  //     "color": "yellow"
  //   }
  // ]

  // projectData=[{
  //   "id": "1",
  //   "name": "Project1",
  //   "progress": "69",
  //   "color": "fuchsia"
  // },
  // {
  //   "id": "2",
  //   "name": "Project2",
  //   "progress": "96",
  //   "color": "teal"
  // },
  // {
  //   "id": "3",
  //   "name": "Project3",
  //   "progress": "33",
  //   "color": "teal"
  // },{
  //   "id": "4",
  //   "name": "Project4",
  //   "progress": "69",
  //   "color": "fuchsia"
  // },
  // {
  //   "id": "5",
  //   "name": "Project5",
  //   "progress": "96",
  //   "color": "teal"
  // },
  // {
  //   "id": "6",
  //   "name": "Project6",
  //   "progress": "33",
  //   "color": "teal"
  // }]

  

  constructor(private _service:ApiService,private _authService:AuthService,private  _router:Router,private _shared:SharedService) { }
  ngDoCheck(): void {
    
  }

  ngOnInit(): void {
    console.log(this.cards);
    this.userId=this._authService.getUserId();

    this._service.postData("/cards",{type:"User",user_id:this.userId}).subscribe((data=>{
      console.log("user cards"+data);
      this.cards= data['cards'];
      console.log(this.cards);

      this.cards.forEach(card=>{
        
        for (let key in card){
          if(key == "model_framework_percentage"){
              let pie=card["model_framework_percentage"]
              for(let label in pie){
                this.pieLables.push(label);
                this.pieValues.push(pie[label]);
              }
              console.log("pie graph data")
              console.log(this.pieLables);
              console.log(this.pieValues);
          }
          this.cardTitles.push(key);
          this.cardTitleValues.push(card[key]);
        }

    })
      
    }))


    this._service.postData("/view",{type:"User",user_id:this.userId}).subscribe(userData=>{
      console.log(userData["userData"]);
     this.userData=userData["userData"];
    })

    this._service.postData("/view",{type:"Project",user_id:this.userId}).subscribe(userData=>{
      console.log(userData["projectData"]);
     this.projectData=userData["projectData"];
    })
  }

  openTable(category){
    this.viewTable=true
    if(category == 'user'){

      this.tableData=this.userData;
      this.type="User";
      this.displayedColumns=this.displayedColumnsUsers;
       
    }else{
      this.tableData=this.projectData;
      this.type="Project";
      this.displayedColumns=this.displayedColumnsProjects;
    }
  }

  lightWeight(){
    this._router.navigate(['/initial',{pie:true}]);
    this._shared.getTrain();
  }

}
