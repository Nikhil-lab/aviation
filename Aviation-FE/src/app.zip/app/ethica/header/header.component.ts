import { Component, OnInit, OnDestroy, AfterViewInit, OnChanges } from '@angular/core';
import { AuthService } from '../../auth/auth.service';
import { Subscription } from 'rxjs';

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.css']
})
export class HeaderComponent implements OnInit, OnDestroy{

  private authListenerSubs: Subscription;
  userIsAuthenticated: boolean;

  constructor(private authService: AuthService) { }

  ngOnInit(): void {
    console.log("ngoninit called in header");
      this.authListenerSubs=this.authService.getAuthStatusListner()
          .subscribe(isAuthenticated=>{
            console.log("isAuthenticated from header")
            console.log(isAuthenticated)
            this.userIsAuthenticated=isAuthenticated;
      });
  }


  ngOnDestroy(): void {
    console.log("ngOnDestroy called in header");
    
    this.authListenerSubs.unsubscribe();
  }

  logout(){
    this.authService.logout();
  }

}
