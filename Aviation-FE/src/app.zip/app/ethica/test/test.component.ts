import { Component, OnInit, ViewChild, AfterViewInit } from '@angular/core';
import { ApiService } from '../api/api.service';
import {UserComment} from '../comment.model'

import {MatSnackBar} from '@angular/material/snack-bar';
import { SnackBarComponent } from '../snack-bar/snack-bar.component';
import {map} from "rxjs/operators";
import { AuthService } from '../../auth/auth.service';
import { Router } from '@angular/router';

declare var $: any;

@Component({
  selector: 'app-test',
  templateUrl: 'test.component.html',
  styleUrls: ['test.component.css']
})
export class TestComponent implements OnInit ,AfterViewInit{
  comment:string;
  userComment:any;
  reviewComment:any;
  userIsAuthenticated: boolean;
  test1:boolean;
  para1=10;
  para2=10;
  para3=10;
  @ViewChild('myname') input;  
  @ViewChild('slider')slider;
   checkTotal=100;
  scoreTotal=101;
  allTotal=0;

  constructor(private router: Router,private authService:AuthService,private service:ApiService,private _snackBar: MatSnackBar) { }
  ngAfterViewInit(): void {
     console.log("value of myname")
      console.log(this.input.nativeElement.value);
    
  }

  ngOnInit(): void {

    

    var tota, totb, totc, alltot, altval, getslider;
var chktot = 100;
var scrore = 101;

//On Change event 

$(document).on("change", "#range1, #range2, #range3,#range5", function (e) {

    // Get the sliders Id
    getslider = $(this).attr("id");

    //Gather all slider values
    tota = parseInt($("input#range1").val());
    totb = parseInt($("input#range2").val());
    totc = parseInt($("input#range3").val());
    alltot = tota + totb + totc;

    //check sliders total if greater than 150 and re-update slider 
    if (alltot > chktot) {
        if (getslider == "range1") {
            altval = chktot - totb - totc;
            $("input#range1").val(altval).slider("refresh");;
        }
        if (getslider == "range2") {
            altval = chktot - tota - totc;
            $("input#range2").val(altval).slider("refresh");;
        }
        if (getslider == "range3") {
            altval = chktot - tota - totb;
            $("input#range3").val(altval).slider("refresh");;
        }
    }

    //Update Total
    if (alltot < scrore) {
        $("#total").text(alltot);
    }
})


    /*
===============================================================

Hi! Welcome to my little playground!

My name is Tobias Bogliolo. 'Open source' by default and always 'responsive',
I'm a publicist, visual designer and frontend developer based in Barcelona. 

Here you will find some of my personal experiments. Sometimes usefull,
sometimes simply for fun. You are free to use them for whatever you want 
but I would appreciate an attribution from my work. I hope you enjoy it.

===============================================================
*/
//Global:
var survey = []; //Bidimensional array: [ [1,3], [2,4] ]

//Switcher function:
$(".rb-tab").click(function(){
  //Spot switcher:
  $(this).parent().find(".rb-tab").removeClass("rb-tab-active");
  $(this).addClass("rb-tab-active");
});

//Save data:
$(".trigger").click(function(){
  //Empty array:
  survey = [];
  //Push data:
  for (let i=1; i<=$(".rb").length; i++) {
    var rb = "rb" + i;
    var rbValue = parseInt($("#rb-"+i).find(".rb-tab-active").attr("data-value"));
    //Bidimensional array push:
    survey.push([i, rbValue]); //Bidimensional array: [ [1,3], [2,4] ]
  };
  //Debug:
  // debug();
});

//Debug:
// function debug(){
//   var debug = "";
//   for (i=0; i<survey.length; i++) {
//     debug += "Nº " + survey[i][0] + " = " + survey[i][1] + "\n";
//   };
//   alert(debug);
// };

    console.log("this is called in test component ng onint")
    this.authService.getAuthStatusListner().subscribe(isAuthenticated =>{
      this.userIsAuthenticated = isAuthenticated;
      console.log("user is authenticated from test component")
      console.log(this.userIsAuthenticated);
    });
   

    // this._snackBar.open("hello boss");
  
    this._snackBar.openFromComponent(SnackBarComponent, {
      duration: 2000,
       data:"Hello Boss",
      verticalPosition: 'top',
      horizontalPosition : 'end'

    });
  }


  sliderChange(value){
    console.log(this.input.nativeElement);
    console.log(value);
  }

  save(){
     let userComment ={
      comment:this.comment
    }
  
    this.service.postData('/userComments',userComment).subscribe(data => {
      console.log(data);
      this.retrive();

      this._snackBar.openFromComponent(SnackBarComponent,{
        duration:3000,
        data:"User Comments saved successfully",
        verticalPosition: 'top'

      })
      
    })
  }

  retrive(){


    

    this.service.getdata('/userComments')
    .pipe(map((postData)=>{
      console.log(postData);
      return postData['comments'].map(comment=>{
        return{
          id:comment['_id'],
          updatedComment:comment['comment']

        };
      });
    }))
    .subscribe(convertedData => {
      console.log("after Converting the data")
      console.log(convertedData);
      this.userComment =convertedData;
      
      
    })
  }


  

  deleteComment(commentId:string){

    this.service.deleteData('/userComments',commentId).subscribe(result=>{
      console.log("Deleted Comment");
      this.retrive();
    });

  }

  reviewComments(){

   

    this.service.getdata("/reviewComments").subscribe(data => {
      console.log(data);
      this.reviewComment=data;
    })
  }

  changeStatus(){
    this.authService.changeStatus();
    this.router.navigate(['/appraisal']);
  }

  receiveMessage($event){
    console.log("received message fromm child");
    console.log($event);
  }


  changing(para){
    let checkTotal=100
    let scoreTotal=101

    this.allTotal =this.para1+this.para2+this.para3;
    console.log("allTotal:"+this.allTotal);

    if(this.allTotal > checkTotal){
      if(para == "1"){
        this.slider.value = this.checkTotal- this.para2 -this.para3
        this.para1=this.slider.value
        console.log("slider value"+this.slider.value);
      }
    }


  }



}
