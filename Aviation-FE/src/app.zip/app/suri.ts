
    /* ------app.component.ts------*/

    

import { Component,ViewChild,ComponentFactoryResolver,ComponentFactory,ViewContainerRef,ComponentRef } from'@angular/core';
import*asdatafrom'./sample.json';
import { BarChartComponent } from'./bar-chart/bar-chart.component';
import { LineChartComponent } from'./line-chart/line-chart.component';
import { PieChartComponent } from'./pie-chart/pie-chart.component';
import { DoughnutChartComponent } from'./doughnut-chart/doughnut-chart.component';
import { RadarChartComponent } from'./radar-chart/radar-chart.component';
import { PolarChartComponent } from'./polar-chart/polar-chart.component';
import { LollipopChartComponent } from'./lollipop-chart/lollipop-chart.component';
import { AreaChartComponent } from'./area-chart/area-chart.component';
@Component({
selector:'app-root',
templateUrl:'./app.component.html',
styleUrls: ['./app.component.css']
})
export class AppComponent {
title = 'root';
componentRef : any;
obj : Array<any> = (dataasany).default;
  @ViewChild('load_graphs',{read :ViewContainerRef})
entry : ViewContainerRef;
constructor(privateresolver : ComponentFactoryResolver){}
createComponents(comp : Array<any>)
  {
var com : any;
for(vari=0;i<comp.length;i++)
    {
if(comp[i].type=="BarChart_1" || comp[i].type=="BarChart_2")
com=BarChartComponent;
elseif(comp[i].type=="PieChart_1" || comp[i].type=="PieChart_2")
com=PieChartComponent;
elseif(comp[i].type=="LineChart_1" || comp[i].type=="LineChart_2")
com=LineChartComponent;
elseif(comp[i].type=="DoughnutChart_1" || comp[i].type=="DoughnutChart_2")
com=DoughnutChartComponent;
elseif(comp[i].type=="RadarChart_1" || comp[i].type=="RadarChart_2")
com=RadarChartComponent;
elseif(comp[i].type=="PolarChart_1" || comp[i].type=="PolarChart_2")
com=PolarChartComponent;
elseif(comp[i].type=="LollipopChart_1" || comp[i].type=="LollipopChart_2")
com=LollipopChartComponent;   
elseif(comp[i].type=="AreaChart_1" || comp[i].type=="AreaChart_2")
com=AreaChartComponent;
else
continue;
constfactory = this.resolver.resolveComponentFactory(com);
this.componentRef=this.entry.createComponent(factory);
this.componentRef.instance.temp = comp[i];
    }
  }
checkJson()
  {
this.createComponents(this.obj);
  }
}

​
    /*-----app.component.html-----*/

    

<br><br>
<divclass=" offset-lg-4 col-lg-3">
<buttonclass="btn btn-success btn-block"(click)="checkJson()"> CheckJson()!</button>
</div>
<divclass="container-fluid"style="padding: 0px; margin: 0px;">
<div class="row"style="padding: 0px;">
<ng-template#load_graphs></ng-template>
</div>
</div>


    /*-------line-chart.component.ts---------*/

    

import { Component, OnInit,Input } from'@angular/core';
import*asd3from'd3';
import { Globals } from'../globals';
import {axisBottom,axisLeft} from'd3';
@Component({
selector:'app-line-chart',
templateUrl:'./line-chart.component.html',
styleUrls: ['./line-chart.component.css'],
providers : [Globals]
})
export class LineChartComponent implements OnInit {
constructor(privateglobals : Globals) { }
  @Input() temp : Array<any>=[];
publicfactor : number;
publicwidth : number;
publicheight : number;
publicpadding : number;
publicobj : Array<any>=[];
publicflag : Array<number>=[];
publiclabels : Array<any>=[];
publicid : string;
ngOnInit(): void {
this.id = this.globals.generateId("myChart");
if(this.temp["type"]=="LineChart_1")
    {
this.factor=0.25;
    }
else
    {
this.factor=0.45;
    }
this.width=this.factor*window.innerWidth;
this.height=0.5*window.innerHeight;
this.padding=0.05*this.width;
for(leti=0;i<this.temp["data"].length;i++)
    {
this.flag.push(this.temp["data"][i].value);
this.labels.push(this.temp["data"][i].name);
this.obj.push(this.temp["data"][i]);
    }    
  }
ngAfterViewInit(){
varmargin = { top :30, bottom :30, left :30, right :30};
varx = this.width - margin.left - margin.right;
vary = this.height - margin.top - margin.bottom;
varsvg = d3.select("#"+this.id)
    .append('svg')
    .attr('width',this.width)
    .attr('height',this.height)
    .append('g')
    .attr('transform',"translate("+margin.left+","+margin.top+")");   
varxScale = d3.scaleLinear()
    .domain([0,d3.max(this.labels)])
    .range([0,x]);
varyScale = d3.scaleLinear()
    .domain([0,d3.max(this.flag)])
    .range([y,0]); 
svg.append('g')
    .attr("transform","translate(0,"+y+")")
    .call(axisBottom(xScale));
svg.append('g').call(axisLeft(yScale));
console.log(this.obj);
svg.append('path')
    .datum(this.obj)
    .attr('fill','none')
    .attr('stroke','lightblue')
    .attr('stroke-width',3)
    .attr('d',d3.line()
    .x(function(d){returnxScale(d['name']);})
    .y(function(d){returnyScale(d['value']);}));
svg.selectAll('myCircles')
    .data(this.obj)
    .enter()
    .append('circle')
    .attr('fill','brown')
    .attr('cx',function(d){ returnxScale(d.name);})
    .attr('cy',function(d){ returnyScale(d.value);})
    .attr('r',2);
  }
}


    /*------line-chart.component.html--------*/

    

<divclass="card shadow mb-4 mr-4">
<divclass="card-body">
<div[id]="id"[style.width.px]="width"[style.height.px]="height"
[style.padding.right.px]="[padding]"[style.padding.left.px]="padding">
</div>
</div>
</div>



DATA

[

    {
        "type" : "LineChart_1",
        "data" :[
            {
                "name" : 1,
                "value" : 43
            },
            {
                "name" : 2,
                "value" : 53
            },
            {
                "name" : 3,
                "value" : 50
            },
            {
                "name" : 4,
                "value" : 57
            },
            {
                "name" : 5,
                "value" : 59
            },
            {
                "name" : 6,
                "value" : 67
            }
        ]
    },
    {
        "type" : "PieChart_1",
        "data" : [
            {
                "name" : "action",
                "value" : 30
            },
            {
                "name" : "fiction",
                "value" : 15
            },
            {
                "name" : "horror",
                "value" : 10
            },
            {
                "name" : "fantasy",
                "value" : 20
            }
        ]
    }
    ]



    /*------pie-chart.component.ts------*/

    

import { Component, OnInit, Input } from'@angular/core';
 
@Component({
selector:'app-pie-chart',
templateUrl:'./pie-chart.component.html',
styleUrls: ['./pie-chart.component.css']
})
exportclassPieChartComponentimplementsOnInit {
  @Input() temp : Array<any>;
constructor() { }
publictype="pie";
publiclabels : Array<any>=[];
publicdata : Array<any>=[];
publicfactor : number;
publicwidth : number;
publicheight : number;
publicpadding : number;
ngOnInit(): void {
if(this.temp["type"]=="PieChart_1")
    {
this.factor=0.25;
    }
else
    {
this.factor=0.45;
    }
this.width=this.factor*window.innerWidth;
this.height=0.5*window.innerHeight;
this.padding=0.05*this.width;
for(leti=0;i<this.temp["data"].length;i++)
    {
this.labels.push(this.temp["data"][i].name);
this.data.push(this.temp["data"][i].value);
    }
  }
}

​[Yesterday 3:26 PM] Suri Saikiran (HOLMES)
    /*-----pie-chart.component.html------*/
​[Yesterday 3:26 PM] Suri Saikiran (HOLMES)
    

<divclass="card shadow mb-4 mr-4">
<divclass="card-body">
<div[style.width.px]="width"[style.height.px]="height"[style.padding.right.px]="[padding]"[style.padding.left.px]="padding">
<canvas[width]="width"[height]="height"
baseChart
[labels]="labels"
[data]="data"
[chartType]="type">
</canvas>
</div>
</div>
</div>

/*-----globals.ts------*/


 
 
import { Injectable } from '@angular/core';
 
@Injectable()
export class Globals {
    generateId(prefix : string){
        return Math.random().toString(36).replace('0.',prefix || '');
    }
}